<?php
namespace nanaobiriyeboahcompanion;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_breadcrumb;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_poppup;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_blog;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_event;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_music;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_pp_blog;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_church;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_category_search;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_faq;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_topics;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_map;
use nanaobiriyeboahcompanion\Widgets\Package_tab;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_empower;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_timeline;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_career;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_image_box;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_apply_popup;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_project;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_provider_logo;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_image_box_slider;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_course;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_courses_sidebar;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_courses_box;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_product;
use nanaobiriyeboahcompanion\Widgets\nanaobiriyeboah_menu_sidebar;

/**
 * Class Plugin
 *
 * Main Plugin class
 * @since 1.2.0
 */
class nanaobiriyeboahPlugin {

	/**
	 * Instance
	 *
	 * @since 1.2.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * widget_scripts
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function widget_scripts() {
		wp_register_script( 'nanaobiriyeboah-companion', plugins_url( '/assets/js/custom.js', __FILE__ ), [ 'jquery' ], false, true );
	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/breadcrumb.php' );
		require_once( __DIR__ . '/widgets/popup.php' );
		require_once( __DIR__ . '/widgets/blog.php' );
		require_once( __DIR__ . '/widgets/events.php' );
		require_once( __DIR__ . '/widgets/music.php' );
		require_once( __DIR__ . '/widgets/popular_blog.php' );
		require_once( __DIR__ . '/widgets/church.php' );
		require_once( __DIR__ . '/widgets/category_search.php' );
		require_once( __DIR__ . '/widgets/faq.php' );
		require_once( __DIR__ . '/widgets/topics.php' );
		require_once( __DIR__ . '/widgets/map.php' );
		require_once( __DIR__ . '/widgets/Package_tab.php' );
		require_once( __DIR__ . '/widgets/empower.php' );
		require_once( __DIR__ . '/widgets/timeline.php' );
		require_once( __DIR__ . '/widgets/career.php' );
		require_once( __DIR__ . '/widgets/img-box.php' );
		require_once( __DIR__ . '/widgets/apply_popup.php' );
		require_once( __DIR__ . '/widgets/project.php' );
		require_once( __DIR__ . '/widgets/provider_logo.php' );
		require_once( __DIR__ . '/widgets/img-box-slider.php' );
		require_once( __DIR__ . '/widgets/course_list.php' );
		require_once( __DIR__ . '/widgets/courses_sidebar.php' );
        require_once( __DIR__ . '/widgets/courses_box.php' );
		require_once( __DIR__ . '/widgets/product.php' );
		require_once( __DIR__ . '/widgets/menu_sidebar.php' );
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_breadcrumb() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_poppup() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_blog() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_event() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_music() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_pp_blog() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_church() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_category_search() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_faq() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_topics() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_map() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Package_tab() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_empower() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_timeline() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_career() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_image_box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_apply_popup() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_project() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_provider_logo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_image_box_slider() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_course() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_courses_sidebar() );
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_courses_box() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_product() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new nanaobiriyeboah_menu_sidebar() );
	}

	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function __construct() {

		// Register widget scripts
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
	}
}

// Instantiate Plugin Class
nanaobiriyeboahPlugin::instance();