<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_related_activitie extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-related-activities';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Related Activities', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}


	protected function _register_controls()
    {
        // add content
        $this->_content_control();
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_related_activitie_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

		$this->add_control(
			'cre_related_activitie_content_image',
			[
				'label' => __( 'Choose Image', 'elementor' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'cre_related_activitie_title', [
				'label' => __( 'Title', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Tour Title' , 'nanaobiriyeboah-companion' ),
			]
		);
		$this->add_control(
			'cre_related_activitie_content', [
				'label' => __( 'Content', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'Tour Content' , 'nanaobiriyeboah-companion' ),
			]
		);
		$this->add_control(
			'banner_btn_1',
			[
				'label' => esc_html__( 'Button 1', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'related_btn_text_1',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Learn More', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Type Your Text', 'nanaobiriyeboah-companion' ),
			]
		);

		$this->add_control(
			'related_btn_url_1',
			[
				'label' => __( 'Button Link', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'nanaobiriyeboah-companion' ),
			]
		);

		$this->add_control(
			'banner_btn_2',
			[
				'label' => esc_html__( 'Button 2', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'related_btn_text_2',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Book Now', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Type Your Text', 'nanaobiriyeboah-companion' ),
			]
		);

		$this->add_control(
			'related_btn_url_2',
			[
				'label' => __( 'Button Link', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'nanaobiriyeboah-companion' ),
			]
		);

		$this->add_control(
			'related_activitie_meta_heading_1',
			[
				'label' => esc_html__( 'Age', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'related_activitie_meta_icon_1',
			[
				'label' => esc_html__( 'Icon', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'related_activitie_meta_text_1',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '1 Hour', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Type Your Text', 'nanaobiriyeboah-companion' ),
			]
		);
		$this->add_control(
			'related_activitie_meta_heading_2',
			[
				'label' => esc_html__( 'Hour', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'related_activitie_meta_icon_2',
			[
				'label' => esc_html__( 'Icon', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'related_activitie_meta_text_2',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Ages 18+', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Type Your Text', 'nanaobiriyeboah-companion' ),
			]
		);
		$this->add_control(
			'related_activitie_meta_heading_3',
			[
				'label' => esc_html__( 'Budget', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'related_activitie_meta_icon_3',
			[
				'label' => esc_html__( 'Icon', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'related_activitie_meta_text_3',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '$105.00', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Type Your Text', 'nanaobiriyeboah-companion' ),
			]
		);
        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);

        ?>
           <div class="related_activitie_content">
				<div class="related_activitie_thumb">
					<img src="<?php echo esc_url($cre_related_activitie_content_image['url']) ?>" alt="#" class="img-fluid">
				</div>
				<div class="related_activitie_inner">
					<div class="activitie_meta_list d-flex flex-wrap justify-content-between">
						<div class="meta_list_inner">
							<div class="meta_item">
								<?php if( !empty($related_activitie_meta_icon_1)) : ?>
									<?php \Elementor\Icons_Manager::render_icon( $related_activitie_meta_icon_1, [ 'aria-hidden' => 'true' ] ); ?>
								<?php endif; ?>
								<?php echo esc_html($related_activitie_meta_text_1); ?> 
							</div>
							<div class="meta_item">
								<?php if( !empty($related_activitie_meta_icon_2)) : ?>
									<?php \Elementor\Icons_Manager::render_icon( $related_activitie_meta_icon_2, [ 'aria-hidden' => 'true' ] ); ?>
								<?php endif; ?>
								<?php echo esc_html($related_activitie_meta_text_2); ?> 
							</div>
						</div>
						
						<div class="meta_item style_2">
							<?php if( !empty($related_activitie_meta_icon_3)) : ?>
								<?php \Elementor\Icons_Manager::render_icon( $related_activitie_meta_icon_3, [ 'aria-hidden' => 'true' ] ); ?>
							<?php endif; ?>
							<?php echo $related_activitie_meta_text_3; ?>
						</div>
					</div>
					<h4 class="title"><?php echo $cre_related_activitie_title ?></h4>
					<p class="description"><?php echo $cre_related_activitie_content ?></p>
					<div class="related_activitie_btn d-flex flex-wrap align-items-center">
						<?php
							echo '<a class="cu_btn base_btn" href="' . $related_btn_url_1['url'] . '">'. esc_html($related_btn_text_1) .'</a>';
						?>
						<?php
							echo '<a class="cu_btn btn_3" href="' . $related_btn_url_2['url'] . '">'. esc_html($related_btn_text_2) .'</a>';
						?>
					</div>
				</div>
			</div>
        <?php
		
	}
	
}
