<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_category extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-category';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Category', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_category_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

		
        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );
        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		$product_categories = get_terms( array(
			'taxonomy' => 'product_cat',
			'hide_empty' => true,
			'number' => 3
		));
        ?>
           <div class="cre_category_section_wrapper">
				<div class="cre_product_category">
					<?php
						// Loop through each product category
						foreach ( $product_categories as $category ) {
							$term_id  = $category->term_id;
							$term_img = get_term_meta( $term_id, 'thumbnail_id', true );
							// Get category image URL
							$image_url = wp_get_attachment_url( $term_img );
							// Output category name and image
							$category_url = get_term_link($term_id, 'product_cat');
							?>
								<div class="product-category" data-bg-img="<?php echo $image_url; ?>">
									<div class="category_content">
										<h5 class="title"><?php echo $category->name; ?></h5>
										<a class="read_more_btn" href="<?php echo $category_url; ?>">Shop Now</a>
									</div>
						        </div>
							<?php
						}
					?>
				</div>
			</div>
        <?php
		
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
