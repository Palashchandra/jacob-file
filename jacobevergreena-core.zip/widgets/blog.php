<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_blog extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-blog';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Blog', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

    protected function _register_controls()
    {
        $this->_content_control();
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_testimonial_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );
		$this->add_control(
			'blog_orderby',
			[
				'label' => esc_html__( 'Post Orderby', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'  => esc_html__( 'Date', 'nanaobiriyeboah-companion' ),
					'title' => esc_html__( 'Title', 'nanaobiriyeboah-companion' ),
					'comment_count' => esc_html__( 'Popular', 'nanaobiriyeboah-companion' ),
				],
			]
		);
		$this->add_control(
			'blog_order',
			[
				'label' => esc_html__( 'Post Order', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'desc'  => esc_html__( 'desc', 'nanaobiriyeboah-companion' ),
					'asc' => esc_html__( 'asc', 'nanaobiriyeboah-companion' ),
				],
			]
		);
        $this->end_controls_section();
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		$args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => 3,
			'orderby'        => $blog_orderby,
			'order'          => $blog_order,
		);

		$query = new WP_Query($args);
        ?>
           <div class="cre_blog_section_wrapper">
				<?php
				if ($query->have_posts()) :
					while ($query->have_posts()) : $query->the_post();
						// Your post content here
						$category = get_the_category();
						$first_category= !empty($category) ? $category[0] : false;
						?>
							<div class="blog_post_item">
							    <?php if(!empty(get_the_post_thumbnail_url())) : ?>
									<a href="<?php echo get_the_permalink(); ?>" class="post_thumb">
									    <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#" class="img-fl">
								    </a>
								<?php endif; ?>
								
								<div class="post_content">
									<div class="post_meta">
										<?php if(!empty($first_category)) : ?>
										    <p class="category"><?php echo $first_category->name; ?></p>
										<?php endif; ?>
										<p class="post-date">
											<?php echo get_the_date('j M, Y'); ?>
										</p>
									</div>
									<h5 class="title"><a href="<?php echo get_the_permalink(); ?>"><?php echo the_title(); ?></a></h5>
									<p class="description"><?php echo wp_trim_words(get_the_excerpt(), 10, '....') ; ?></p>
									<a href="<?php echo get_the_permalink(); ?>" class="read_more">Read More <i class="fas fa-arrow-right"></i></a>
								</div>
							</div>
						<?php
					endwhile;
				endif;
	
				wp_reset_postdata();
				?>
           </div>
        <?php
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
