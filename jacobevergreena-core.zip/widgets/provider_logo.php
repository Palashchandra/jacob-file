<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class nanaobiriyeboah_provider_logo extends Widget_Base {

    public function get_name() {
        return 'nanaobiriyeboah-provider-logo';
    }

    public function get_title() {
        return __( 'Provider logo', 'nanaobiriyeboah-companion' );
    }

    public function get_icon() {
        return 'eicon-social-icons';
    }

    public function get_categories() {
        return [ 'nanaobiriyeboah' ];
    }

    protected function _register_controls() {

        $this->register_style_control();

        $this->content_control_style_01();

        $this->content_control_style_02();

    }

    public function register_style_control() {
        $this->start_controls_section(
            'style_sec', [
                'label' => esc_html__( 'Preset Skins', 'nanaobiriyeboah-companion' ),
            ]
        );

        $this->add_control(
            'style', [
                'label' => __( 'Style', 'nanaobiriyeboah-companion' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_01' => esc_html__('Style 01', 'nanaobiriyeboah-companion'),
                    'style_02' => esc_html__('Style 02', 'nanaobiriyeboah-companion'),
                ],
                'default' => 'style_01'
            ]
        );

        $this->end_controls_section();
    }

    public function content_control_style_01() {
        $this->start_controls_section(
            '_cre_provider_logo_section_style_01',
            [
                'label' => __('Provider Logo Style 01', 'nanaobiriyeboah-companion'),
                'condition' => [
                    'style' => 'style_01'
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'cre_provider_logo_image',
            [
                'label' => esc_html__( 'Choose Image', 'textdomain' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'cre_provider_logo_repeter_item_style_01',
            [
                'label' => __( 'Repeater List', 'nanaobiriyeboah-companion' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'cre_provider_logo_title' => __( 'logo', 'nanaobiriyeboah-companion' ),

                    ],
                ],
                'title_field' => '{{{ cre_provider_logo_title }}}',
            ]
        );

        $this->end_controls_section();
    }

    public function content_control_style_02() {
        $this->start_controls_section(
            '_cre_provider_logo_section_style_02',
            [
                'label' => __('Provider Logo Style 02', 'nanaobiriyeboah-companion'),
                'condition' => [
                    'style' => 'style_02'
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'cre_provider_logo_image',
            [
                'label' => esc_html__( 'Choose Image', 'textdomain' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'btn_text',
            [
                'label' => esc_html__( 'Button Title', 'nanaobiriyeboah-companion' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Learn More',
            ]
        );

        $repeater->add_control(
            'btn_link',
            [
                'label' => __( 'Link', 'nanaobiriyeboah-companion' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __( 'https://your-link.com', 'nanaobiriyeboah-companion' ),
                'default' => [
                    'url' => '#'
                ],
            ]
        );

        $repeater->add_control(
            'btn_icon',
            [
                'label' => __( 'Icon', 'nanaobiriyeboah-companion' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
            ]
        );

        $this->add_control(
            'cre_provider_logo_repeter_item_style_02',
            [
                'label' => __( 'Repeater List', 'nanaobiriyeboah-companion' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'cre_provider_logo_title' => __( 'logo', 'nanaobiriyeboah-companion' ),

                    ],
                ],
                'title_field' => '{{{ cre_provider_logo_title }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if ($settings['style'] == 'style_01') {
            ?>
            <div class="cre_provider_logo_wrapper">
                <?php
                if (!empty($settings['cre_provider_logo_repeter_item_style_01'])) {
                    foreach ($settings['cre_provider_logo_repeter_item_style_01'] as $item) {
                        ?>
                        <div class="provider_logo_inner">
                            <img src="<?php echo $item['cre_provider_logo_image']['url'] ?>" alt="#" class="img-fluid">
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
            <?php
        } elseif ($settings['style'] == 'style_02') {
            ?>
            <div class="cre_provider_logo_wrapper provider_logo_grid">
                <?php
                if (!empty($settings['cre_provider_logo_repeter_item_style_02'])) {
                    foreach ($settings['cre_provider_logo_repeter_item_style_02'] as $item) {
                        ?>
                        <div class="provider_logo_inner">
                            <img src="<?php echo $item['cre_provider_logo_image']['url'] ?>" alt="#" class="img-fluid">
							<a href="<?php echo $item['btn_link']['url'] ?>" class="course_btn"><?php echo $item['btn_text'] ?><?php \Elementor\Icons_Manager::render_icon( $item['btn_icon'] ); ?></a>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
            <?php
        }
    }

    protected function _content_template() {
    }
}
