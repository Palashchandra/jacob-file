<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_shadow;



// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class Package_tab extends Widget_Base {

    public function get_name() {
        return 'Package-tab';
    }

    public function get_title() {
        return __( 'Package Tab', 'nanaobiriyeboah-companion' );
    }

    public function get_icon() {
        return 'eicon-tabs';
    }

    public function get_categories() {
        return [ 'bombbatle-elements' ];
    }

    protected function register_controls() {

        // content control 
        $this-> tab_repetar_controls();

    }

    // Ordering Repeater
    public function tab_repetar_controls(){
        $this->start_controls_section(
            'tab_repeater_section',
            [
                'label' => esc_html__('Tabs', 'john-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_responsive_control(
            'tab_icon_image',
            [   
                'label' => esc_html__('Image', 'john-core'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $repeater->add_control(
            'tab_title', [
                'label' => __('Tab Title', 'marionpt-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => __('Enter Title', 'marionpt-core'),
                'default' => __('', 'marionpt-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'tab_content',
            [
                'label' => __( 'Tab Content', 'marionpt-core' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Take advantage of our offers today.', 'john-core'),
            ]
        );
		$repeater->add_control(
			'tab_button',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Learn More', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Learn More', 'nanaobiriyeboah-companion' ),
			]
		);

		$repeater->add_control(
			'tab_button_url',
			[
				'label' => esc_html__( 'Link', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url' ],
				'default' => [
					'url' => '',
				],
				'label_block' => true,
			]
		);
        $repeater->add_control(
            'tab_content_shortcode',
            [
                'label' => __( 'Tab Shortcode', 'marionpt-core' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( '[hfe_template id="1860"]', 'john-core'),
            ]
        );
       
        $this->add_control(
            'tab_list',
            [
                'label' => __('tab', 'john-core'),
                'show_label' => false,
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tab_icon_image' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                        'tab_title' => 'Online instructor-led',
                        'tab_content' => __( 'Take advantage of our offers today and embark on a budget-friendly, impactful learning journey.', 'john-core' ),
                    ],
                    [
                        'tab_icon_image' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                        'tab_title' => 'Classroom',
                        'tab_content' => __( 'Take advantage of our offers today and embark on a budget-friendly, impactful learning journey.', 'john-core' ),
                    ],
                    [
                        'tab_icon_image' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                        'tab_title' => 'Self-paced',
                        'tab_content' => __( 'Take advantage of our offers today and embark on a budget-friendly, impactful learning journey.', 'john-core' ),
                    ],
                    [
                        'tab_icon_image' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                        'tab_title' => 'Group Training',
                        'tab_content' => __( 'Take advantage of our offers today and embark on a budget-friendly, impactful learning journey.', 'john-core' ),
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );
        $this->end_controls_section();
    }
    // <!-- Html render -->
    protected function render() {
        $settings = $this->get_settings_for_display();
        extract($settings);
        $id_int = substr( $this->get_id_int(), 0, 3 );
        ?>


<div class="package_tab wow fadeInUp" data-wow-delay="0.3s">

    <ul class="nav nav-tabs">
        <?php foreach($tab_list as $index => $tab) {
                
                $tab_count = $index + 1;
                $tab_title_setting_key = $this->get_repeater_setting_key( 'tab_title', '$tab', $index );
                $active = $tab_count == 1 ? 'active' : '';
                $select = $tab_count == 1 ? 'true' : 'false';
                $this-> add_render_attribute( $tab_title_setting_key, [
                    'class' => [ 'nav-link tab_link loan_tab_button', $active],
                    // 'id' => 'jac'.'-tab-'.$id_int . $tab_count,
                    'data-bs-toggle' => 'tab',
                    'area-current' => 'page',
                    'aria-selected'=> $select,
                    'role' => 'tab',
                    'href' => '#flush-collapse-' . $id_int . $tab_count,
                ]);
            ?>
        <li class="nav-item">
            <a <?php echo $this->get_render_attribute_string($tab_title_setting_key); ?>>
                <img src="<?php echo esc_url($tab['tab_icon_image']['url']); ?>" alt="img-<?php echo $tab_count;?>" />
                <h4><?php echo esc_html__($tab['tab_title']);?></h4>
                <p><?php echo esc_html__($tab['tab_content']);?></p>
				<span class="learn_btn">
					<?php echo esc_html__($tab['tab_button'])?><svg xmlns="http://www.w3.org/2000/svg" width="23" height="19" viewBox="0 0 23 19" fill="none"><path d="M21.1172 9.41471L1.74219 9.41471" stroke="#818181" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path><path d="M13.3027 1.633L21.1173 9.414L13.3027 17.1963" stroke="#818181" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path></svg>
				</span>
            </a>
        </li>
        <?php } ?>
    </ul>
    <div class="accordion accordion-flush" id="accordionFlushExample<?php echo $id_int?>">
        <?php foreach($tab_list as $index => $tab) {
                $tab_counts = $index + 1;
                $actives = $tab_counts == 1 ? 'show' : '';
				$col = $tab_counts == 1 ? '' : 'collapsed';
                $tab_content_setting_key = $this->get_repeater_setting_key( 'tab_content', '$tab', $index );
                $this->add_render_attribute( $tab_content_setting_key, [
                    'class' => [ 'accordion-collapse collapse', $actives ],
                    'id' => 'flush-collapse-' . $id_int . $tab_counts,
                    'role' => 'tabpanel',
                    
                ]);
            ?>
        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button <?php echo $col; ?>" type="button" data-bs-toggle="collapse"
                    data-bs-target="#flush-collapse-<?php echo $id_int . $tab_counts;?>" aria-expanded="false"
                    aria-controls="flush-collapse-<?php echo $id_int . $tab_counts;?>">
                    <img src="<?php echo esc_url($tab['tab_icon_image']['url']); ?>"
                        alt="img-<?php echo $tab_counts;?>" />
                    <h4><?php echo esc_html__($tab['tab_title']);?></h4>
                </button>
            </h2>
            <div <?php echo $this->get_render_attribute_string($tab_content_setting_key); ?>
                data-bs-parent="#accordionFlushExample<?php echo $id_int?>">
                <div class="accordion-body">
                    <div class="tab_content">
						<?php
							echo !empty( $tab['tab_content_shortcode'] ) ? do_shortcode($tab['tab_content_shortcode']) : '';
						?>
                    </div>
                </div>
            </div>
        </div>


        <?php } ?>
    </div>

</div>

<script>
;
(function($) {
    "use strict";
    $(document).ready(function() {
        if ($(".package_tab .accordion-item").length) {
            $(".accordion-collapse.collapse.show").each(function() {
                $(this).parent(".accordion-item").addClass("active");
            });

            $(".package_tab .loan_tab_button").on("click", function() {
                var target = $(this).attr("href");
                $(".package_tab .accordion-item").removeClass("active");
                $(".package_tab .loan_tab_button").removeClass("active");
                $(this).addClass("active");
                $(target).closest(".accordion-item").addClass("active");
            });

//             $(".package_tab .accordion-item .accordion-button").on("click", function() {
//                 var targets = $(this).attr("data-bs-target");
//                 $(".package_tab .loan_tab_button").removeClass("active");
//                 $(".package_tab .accordion-item").removeClass("active");
//                 $("a[href='" + targets + "']").addClass("active");
//                 $(targets).closest(".accordion-item").addClass("active");
//             });
        }
    });
})(jQuery);
</script>

<?php }
  
    protected function content_template(){}
}