<?php
namespace randrconscompanion\Widgets;

use Elementor\Widget_Base;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class randrcons_co_star_filter extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'randrcons-co_star_filter';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Co Stars', 'randrcons-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'randrcons' ];
	}

	protected function _register_controls()
    {
        // add content
        $this->_content_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_co_star_filter_section',
            [
                'label' => __('Content', 'randrcons-companion'),
            ]
        );

		$this->add_control(
			'co_star_filter_title',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => esc_html__( 'Find Your Next Co-Star! Start your search here:', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your description here', 'textdomain' ),
			]
		);
        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		?>
		<div class="post-widget">
			

			<!-- Search input -->
			<div class="row">
				<div class="col-lg-3">
					<div class="co_star_sidebar">
						<div class="sidebar_item">
							<h4 class="title"> <?php echo $co_star_filter_title; ?></h4>
						</div>
						<?php
						function generate_taxonomy_checkboxes($taxonomy) {
							$args = array(
								'taxonomy'   => $taxonomy,
								'hide_empty' => true,
							);

							$categories = get_categories($args);

							foreach ($categories as $category) {
								$category_id = $category->term_id;
								$category_posts = get_posts(array(
									'post_type' => 'post',
									'tax_query' => array(
										array(
											'taxonomy' => $taxonomy,
											'field'    => 'term_id',
											'terms'    => $category_id,
										),
									),
								));

								if (!empty($category_posts)) {
									echo '<div class="check_item"><label>';
									echo '<input type="checkbox" name="' . esc_attr($taxonomy) . '[]" value="' . esc_attr($category_id) . '">';
									echo $category->name;
									echo '</label></div>';
								}
							}
						}
						?>

						<div class="sidebar_item sidebar_dropdown">
							<div class="dropdown_title"> <h4>Categories</h4> </div>
							<div class="dropdown_content" id="post-category-list">
								<?php generate_taxonomy_checkboxes('category'); ?>
							</div>
						</div>

						<div class="sidebar_item sidebar_dropdown">
							<div class="dropdown_title"> <h4>Topic</h4> </div>
							<div class="dropdown_content" id="post-topic-list">
								<?php generate_taxonomy_checkboxes('topic'); ?>
							</div>
						</div>

						<div class="sidebar_item sidebar_dropdown">
							<div class="dropdown_title"> <h4>Provider</h4> </div>
							<div class="dropdown_content" id="post-provider-list">
								<?php generate_taxonomy_checkboxes('provider'); ?>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-9">
					<div class="co_star_wrapper">
						<!-- post list -->
						<div id="post-list" class="post-list-wrapper"></div>
						<div class="text-center mt-4">
                            <a href="#"	class="cu_btn base_btn load-more-co-stars" data-page="2">Load More</a>
                        </div>
						
					</div>
				</div>
			</div>
		</div>
		<script>
			jQuery(document).ready(function ($) {
				const loadCategoryData = (page, append) => {

					const postOrder = $('#post-order').val();

					const categoryIds = $('input[name="categorie[]"]:checked').map(function () {
						return $(this).val();
					}).get();
					
					const topicIds = $('input[name="topic[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const providerIds = $('input[name="provider[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const advancedIds = $('input[name="advanced[]"]:checked').map(function () {
						return $(this).val();
					}).get();


					const searchInput = $('#post-search').val();

					const data = {
						action: 'post_widget_ajax',
						fee: categoryIds,
						topic: topicIds,
						provider: providerIds,
					};

					$.ajax({
						url: '<?php echo admin_url("admin-ajax.php") ?>',
						type: 'POST',
						data: data,					
						success: (response) => {
							response.append ? $('#post-list').append(response.data) : $('#post-list').html(response.data);							
							if( response.page ) {
								$('.load-more-co-stars').attr('data-page', response.page).show();
							} else {
								$('.load-more-co-stars').attr('data-page', response.page).hide();
							}
						},
					});
				};

				// Initial load with all posts
				loadCategoryData( 1, '' );

				$('.sidebar_dropdown input').on('change', function() {
					loadCategoryData(1, '');
				});


				$('.load-more-co-stars').on('click', function(e) {
					e.preventDefault();
					const page = $(this).data('page');
					loadCategoryData(page, 'append');
				})
			});

		</script>
        <?php
        
		
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}