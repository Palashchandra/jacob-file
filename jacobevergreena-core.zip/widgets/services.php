<?php
namespace nexpogmbhcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nexpogmbh_services extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nexpogmbh-services';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'services', 'nexpogmbh-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nexpogmbh' ];
	}

	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_services_section',
            [
                'label' => __('Content', 'nexpogmbh-companion'),
            ]
        );

		$this->add_control(
			'cre_services_img',
			[
				'label' => esc_html__( 'Service Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'cre_services_title', [
				'label' => __( 'Service Title', 'nexpogmbh-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( ' Creative strategy' , 'nexpogmbh-companion' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'cre_services_flip_box', [
				'label' => __( 'Service Content', 'nexpogmbh-companion' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( "Stand out on social media with our captivating video content." , 'nexpogmbh-companion' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'cre_services_button', [
				'label' => __( 'Service Button', 'nexpogmbh-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'See More' , 'nexpogmbh-companion' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'cre_services_t_content', [
				'label' => __( 'Service Tab Content', 'nexpogmbh-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( ' Creative strategy' , 'nexpogmbh-companion' ),
				'label_block' => true,
			]
		);
        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nexpogmbh-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
        ?>
<div class="cre_services_section">
    <img src="<?php echo $settings['cre_services_img']['url']; ?>" alt="#" class="img-fluid">
    <h5 class="title"> <?php echo $settings['cre_services_title'] ?></h5>
    <p><?php echo $settings['cre_services_flip_box'] ?></p>
    <a href="#" class="btn btn-primary service_btn"> <?php echo $settings['cre_services_button'] ?>
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle cx="9" cy="9" r="9" fill="white"></circle>
            <path
                d="M11.0858 8.40083H5V9.40083H11.0858L8.4038 12.0828L9.1109 12.7899L13 8.90083L9.1109 5.01172L8.4038 5.71882L11.0858 8.40083Z"
                fill="#1E53C5"></path>
        </svg>
    </a>
    <div class="service_content">
        <?php echo $settings['cre_services_t_content'] ?>
    </div>
</div>
<script>
;
(function($) {
    "use strict";
    $(document).ready(function() {
        $('.service_content').hide();
        $('.cre_services_section').on('click', '.service_btn', function(e) {
            e.preventDefault();
            $(this).closest('.cre_services_section').find('.service_content').slideToggle();
        });
    });
})(jQuery);
</script>
<?php
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}