<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_courses_box extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-courses-box';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Courses Item', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	protected function _register_controls()
    {
       // add content
       $this->_content_control();
    }

	public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_all_course_filter_section',
            [
                'label' => __('Content', 'randrcons-companion'),
            ]
        );

		$this->add_control(
			'all_course_filter_title',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'Filters', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your description here', 'textdomain' ),
			]
		);
		$this->add_control(
            'filter_icon',
            [
                'label' => __( 'Icon', 'hdoctor-core' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'ti-arrow-right',
                    'library' => 'solid',
                ],
            ]
        );
		$this->add_control(
			'all_course_filter_dis',
			[
				'label' => esc_html__( 'Discription', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Current selected course: 152 ', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your description here', 'textdomain' ),
				'label_block' => true,
			]
		);
        
        $this->end_controls_section();
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
        ?>
		<section class="all_courses">
			<div class="row">
				<div class="col-lg-4">
					<?php
						function generate_course_taxonomy_checkboxes() {
							// Get all taxonomies associated with the 'post' post type
							$post_taxonomies = get_object_taxonomies('product', 'objects');

							// Array to store taxonomy names specifically associated with course posts
							$course_taxonomy_names = array('post_tag'); // Default taxonomies

							// Loop through each taxonomy associated with the 'post' post type
							foreach ($post_taxonomies as $taxonomy_name => $taxonomy) {
								// Check if the taxonomy is public and not already in the array
								if ($taxonomy->public && !in_array($taxonomy_name, $course_taxonomy_names)) {
									$course_taxonomy_names[] = $taxonomy_name; // Add taxonomy name to the array
								}
							}

							// Loop through each taxonomy in the course_taxonomy_names array
							foreach ($course_taxonomy_names as $taxonomy_name) {
								$taxonomy = get_taxonomy($taxonomy_name); // Retrieve taxonomy object

								if ($taxonomy && $taxonomy->public) { // Check if taxonomy is public and exists
									$args = array(
										'taxonomy'   => $taxonomy_name,
										'hide_empty' => true,
									);

									$terms = get_terms($args);

									if (!empty($terms)) {
										echo '<div class="sidebar_item sidebar_dropdown">';
										echo '<div class="dropdown_title"> <h4>' . esc_html($taxonomy->labels->singular_name) . '</h4> <i class="fas fa-sort-down"></i></div>';
										echo '<div class="dropdown_content">';
										
										foreach ($terms as $term) {
											$term_id = $term->term_id;
											$term_posts = get_posts(array(
												'post_type' => 'product',
												'tax_query' => array(
													array(
														'taxonomy' => $taxonomy_name,
														'field'    => 'term_id',
														'terms'    => $term_id,
													),
												),
											));

											if (!empty($term_posts)) {
												echo '<div class="check_item"><label>';
												echo '<input type="checkbox" name="' . esc_attr($taxonomy_name) . '[]" value="' . esc_attr($term_id) . '">';
												echo esc_html($term->name) . ' (' . count($term_posts) . ')';
												echo '</label></div>';
											}
										}

										echo '</div></div>'; // Close dropdown_content and sidebar_item
									}
								}
							}
						}
					?>
					<div class="all_course_sidebar">
						<div class="filter_btn">
							<h4 class="title"> <?php echo $all_course_filter_title; ?><?php \Elementor\Icons_Manager::render_icon( $settings['filter_icon'], [ 'aria-hidden' => 'true' ] ); ?></h4>
							<p>
								<?php echo $all_course_filter_dis; ?>
							</p>
						</div>
						<?php generate_course_taxonomy_checkboxes(); ?>
					</div>
				</div>
				<div class="col-lg-8">
					<div id="product-list" class="cre_course_item_inner"></div>
				</div>
			</div>
		</section>
		
		<script>
			jQuery(document).ready(function ($) {
				const loadProductData = (pageNumber) => {
					const categoryIds = $('input[name="category[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const topicIds = $('input[name="topic[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const providerIds = $('input[name="provider[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const tagIds = $('input[name="post_tag[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const deliveryIds = $('input[name="delivery_format[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const levelIds = $('input[name="level[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const data = {
						action: 'product_widget_ajax',
						category: categoryIds,
						topic: topicIds,
						provider: providerIds,
						post_tag: tagIds,
						level: levelIds,
						delivery_format: deliveryIds,
						paged: pageNumber, // Use 'paged' instead of 'page'
					};

					$.ajax({
						url: '<?php echo admin_url("admin-ajax.php") ?>',
						type: 'POST',
						data: data,
						success: (response) => {
							$('#product-list').html(response);
							$('.ch_price').hide();
							// Add event listener for 'See Price' button after content is updated
							$('.course_price').on('click', function (e) {
								e.preventDefault();
								$(this).children('.ch_btn_text').hide();
								$(this).children('.ch_price').show();
							});
						},
					});
				};

				$(document).on('click', '.pagination a', function (e) {
					e.preventDefault();
					const pageNumber = $(this).attr('href').split('/').pop(); // Get page number from pagination link
					loadProductData(pageNumber);
				});

				// Initial load with page number 1
				loadProductData(1);

				$('.sidebar_dropdown input').on('change', function () {
					loadProductData(1);
				});

				function filterDropdown() {
					if ($(window).width()) {
						$(".filter_inner .filter_btn").on("click", function (event) {
							$(this).parent().find(".blog_sidebar").first().toggle(700);
						});
					}
				}
				filterDropdown();
			});
		</script>
           
        <?php
		
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}