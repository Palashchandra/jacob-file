<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_project extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-project';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Project', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_project_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'cre_project_image',
			[
				'label' => esc_html__( 'Choose Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater->add_control(
			'cre_project_title', [
				'label' => __( 'Title', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Solenergi i Indien' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'cre_project_content', [
				'label' => __( 'Content', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'List Content' , 'nanaobiriyeboah-companion' ),
				'show_label' => false,
			]
		);

        $repeater->add_control(
			'cre_project_button_text', [
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Read more about the project' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);

        $repeater->add_control(
			'cre_project_button_icon',
			[
				'label' => esc_html__( 'Button Icon', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-circle',
					'library' => 'fa-solid',
				],
			]
		);

        $repeater->add_control(
			'cre_project_button_link',
			[
				'label' => esc_html__( 'Link', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url'],
				'default' => [
					'url' => ''
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'cre_project_repeter_item',
			[
				'label' => __( 'Repeater List', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
                        'cre_project_title' => __( 'Solenergi i Indien', 'nanaobiriyeboah-companion' ),
						'cre_project_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing 
						elit. Mauris pharetra erat lorem, non accumsan neque pharetra nec. Phasellus eu dolor
						mollis, tempor magna id, accumsan dolor. Praesent quis consectetur turpis. Proin at met.', 
						'nanaobiriyeboah-companion' ),
						
					],
				],
				'title_field' => '{{{ cre_project_title }}}',
			]
		);

        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);

        ?>
           <div class="cre_project_section_wrapper">
            <?php
                if ( $settings['cre_project_repeter_item'] ) {
                    foreach (  $settings['cre_project_repeter_item'] as $item ) {
                        ?>
                            <div class="project_section_item">
                                <img src="<?php echo $item['cre_project_image']['url'] ?>" alt="#" class="img-fluid">
                                <h4 class="title"> <?php echo $item['cre_project_title'] ?></h4>
                                <div class="description"> <?php echo $item['cre_project_content'] ?></div>
                                <a href="<?php echo $item['cre_project_button_link']['url'] ?>" class="read_more"><?php echo $item['cre_project_button_text']; \Elementor\Icons_Manager::render_icon( $item['cre_project_button_icon'], [ 'aria-hidden' => 'true' ] ); ?></a>
                            </div>
                        <?php
                    }
                }
            ?>
           </div>
        <?php
		
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
