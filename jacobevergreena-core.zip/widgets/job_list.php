<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_job_slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-job-slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'job Slider', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	// public function get_script_depends() {
    //     return array('job', 'swiper');
    // }

	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_job_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'cre_job_title', [
				'label' => __( 'Title', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Mark Parker' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'cre_job_content', [
				'label' => __( 'Content', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'We are looking for a sales representative who has a strong understanding of the sales process and excels at generating leads, building relationships, and closing deals.' , 'nanaobiriyeboah-companion' ),
				'show_label' => false,
			]
		);
		
		$repeater->add_control(
			'cre_job_button_text', [
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'APPLY NOW' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'cre_job_button_url', [
				'label' => esc_html__( 'Link', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url' ],
				'default' => [
					'url' => '',
				],
				'label_block' => true,
			]
		);
		$this->add_control(
			'cre_job_repeter_item',
			[
				'label' => __( 'Repeater List', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'cre_job_content' => __( 'We are looking for a sales representative who has a strong understanding of 
						the sales process and excels at generating leads, building relationships, and closing deals.' ),
						'cre_job_title' => __( 'Mark Parker', 'nanaobiriyeboah-companion' ),
					],
				],
				'title_field' => '{{{ cre_job_title }}}',
			]
		);

        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);

        ?>
           <div class="cre_job_section_wrapper">
				<div class="swiper cre_job_slider">
					<div class="swiper-wrapper">
						<?php
							if ( $settings['cre_job_repeter_item'] ) {
								foreach (  $settings['cre_job_repeter_item'] as $item ) {
									?>
									<div class="swiper-slide">
										<div class="job_section_inner">
										    <?php if(!empty($item['cre_job_title'])): ?>
												<h3 class="title"> <?php echo $item['cre_job_title'] ?></h3>
											<?php endif; ?>
											<?php if(!empty($item['cre_job_content'])): ?>
												<div class="description"> <?php echo $item['cre_job_content'] ?></div>
											<?php endif; ?>
											<a class="cu_btn btn_2" href="<?php echo $item['cre_job_button_url']['url'] ?>"><?php echo $item['cre_job_button_text'] ?></a>
										</div>
									</div>
									<?php
								}
							}
						?>
					</div>
				</div>
				<div class="slider_navigation">
					<div class="swiper-job-prev swiper-prev">
					    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="8.333" viewBox="0 0 20 8.333">
							<path id="Icon" d="M4.167,0,8.333-5.029H5V-20H3.333V-5.029H0Z" transform="rotate(90)" fill="#347455"/>
						</svg>
					</div>
					<div class="swiper-job-next swiper-next">
					    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="8.333" viewBox="0 0 20 8.333">
						    <path id="Icon" d="M4.167,0,8.333-5.029H5V-20H3.333V-5.029H0Z" transform="translate(20 8.333) rotate(-90)" fill="#377356"/>
						</svg>
					</div>
				</div>
           </div>
        <?php
		
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
