<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_product extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-product';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Product', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}


	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_product_gallery_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );
        $this->add_control(
			'shop_button_text',
			[
				'label' => esc_html__( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Shop Now', 'nanaobiriyeboah-companion' ),
				'placeholder' => esc_html__( 'Type your title here', 'nanaobiriyeboah-companion' ),
			]
		);
		
        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
        );

        $products = new WP_Query($args);

        if ($products->have_posts()) {
            while ($products->have_posts()) {
                $products->the_post();
                global $product;
                
                echo '<div class="product-wrapper">';
                
                // Display product image
                echo '<div class="product-image">' . $product->get_image() . '</div>';
                
                // Display product name
                echo '<h2 class="product-name">' . get_the_title() . '</h2>';
                
                // Display add-to-cart button
                echo '<div class="add-to-cart">' . do_shortcode('[add_to_cart id="' . $product->get_id() . '"]') . '</div>';
                
                echo '</div>';
            }
            wp_reset_postdata();
        } else {
            echo __('No products found', 'custom-elementor-widgets');
        }
    }
	
}
