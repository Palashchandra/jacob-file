<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_career extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-career';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'career', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

    protected function _register_controls()
    {
        $this->_content_control();
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_testimonial_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );
		$this->add_control(
			'career_orderby',
			[
				'label' => esc_html__( 'Post Orderby', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'  => esc_html__( 'Date', 'nanaobiriyeboah-companion' ),
					'title' => esc_html__( 'Title', 'nanaobiriyeboah-companion' ),
					'comment_count' => esc_html__( 'Popular', 'nanaobiriyeboah-companion' ),
				],
			]
		);
		$this->add_control(
			'career_order',
			[
				'label' => esc_html__( 'Post Order', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'desc'  => esc_html__( 'desc', 'nanaobiriyeboah-companion' ),
					'asc' => esc_html__( 'asc', 'nanaobiriyeboah-companion' ),
				],
			]
		);
        $this->end_controls_section();
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		$args = array(
			'post_type' => 'career',
			'post_status' => 'publish',
			'posts_per_page' => -1,
			'orderby'        => $career_orderby,
			'order'          => $career_order,
		);

		$query = new WP_Query($args);
        ?>
           <div class="cre_career_section_wrapper">
				<?php
				if ($query->have_posts()) :
					while ($query->have_posts()) : $query->the_post();
						?>
							<div class="career_post_item d-flex align-items-center justify-content-between">
                                <h5 class="title"><a href="<?php echo get_the_permalink(); ?>"><?php echo the_title(); ?></a></h5>
                                <a class="read_more_btn" href="<?php echo get_the_permalink(); ?>"><i class="fas fa-caret-right"></i></a>
							</div>
						<?php
					endwhile;
				endif;
	
				wp_reset_postdata();
				?>
           </div>
        <?php
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
