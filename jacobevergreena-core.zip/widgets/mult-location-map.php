<?php
namespace Elementor;

if (!defined('ABSPATH')) exit;

class Custom_Google_Map_Widget extends Widget_Base {

    public function get_name() {
        return 'custom-google-map-widget';
    }

    public function get_title() {
        return __('Custom Google Map', 'custom-google-map-widget');
    }

    public function get_icon() {
        return 'eicon-google-maps';
    }

    public function get_categories() {
        return ['basic'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'custom-google-map-widget'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'location_name',
            [
                'label' => __('Location Name', 'custom-google-map-widget'),
                'type' => Controls_Manager::TEXT,
                'default' => __('New Location', 'custom-google-map-widget'),
            ]
        );

        $this->add_control(
            'locations',
            [
                'label' => __('Locations', 'custom-google-map-widget'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    ['location_name' => __('New York City', 'custom-google-map-widget')],
                    ['location_name' => __('Los Angeles', 'custom-google-map-widget')],
                ],
                'title_field' => '{{{ location_name }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <div class="custom-google-map-widget">
            <div id="map"></div>
        </div>

        <script>
            var locations = <?php echo json_encode($settings['locations']); ?>;
            jQuery(document).ready(function ($) {
                function initMap() {
                    var map = new google.maps.Map(document.getElementById('map'), {
                        center: { lat: 0, lng: 0 }, // Update with your default center
                        zoom: 2, // Update with your default zoom level
                    });

                    locations.forEach(function (location) {
                        var geocoder = new google.maps.Geocoder();
                        geocoder.geocode({ address: location.location_name }, function (results, status) {
                            if (status === 'OK' && results[0]) {
                                var marker = new google.maps.Marker({
                                    map: map,
                                    position: results[0].geometry.location,
                                    title: location.location_name,
                                });
                            }
                        });
                    });
                }

                initMap();
            });
        </script>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Custom_Google_Map_Widget());
