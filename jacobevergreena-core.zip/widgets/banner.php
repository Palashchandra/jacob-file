<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_banner extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-banner';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Banner', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	public function get_script_depends() {
        return array('banner', 'swiper', 'nanaobiriyeboah-wow');
    }

    protected function _register_controls()
    {
        $this->_content_control();
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_testimonial_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cre_background_img',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .banner_section_wrapper',
			]
		);

		$this->add_control(
			'cre_banner_sub_title', [
				'label' => __( 'Sub Title', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'CAPTIVATE • INSPIRE • IMPACT' ),
			]
		);

		$this->add_control(
			'cre_banner_title', [
				'label' => __( 'Title', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( '202 ART & CANNABIS DELIVERY 7 DAYS A WEEK' , 'nanaobiriyeboah-companion' ),
			]
		);

		$this->add_control(
			'cre_banner_content', [
				'label' => __( 'Content', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Browse our selection of products available. Lorem ipsum dolor sit amet, 
                consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' ,
                'nanaobiriyeboah-companion' ),
			]
		);


        $this->add_control(
			'cre_banner_logo_title', [
				'label' => __( 'Logo Titte', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Our trusted partner', 'nanaobiriyeboah-companion' ),
			]
		);
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'cre_logo_img',
			[
				'label' => __( 'Logo Image', 'randrcons-companion' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'cre_banner_logo_repeter_item',
			[
				'label' => __( 'Repeater List', 'randrcons-companion' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
        
		
        
        $this->end_controls_section();
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
        ?>
			<div class="banner_section_wrapper position-relative">
				<div class="container">
					<div class="row">
						<div class="col-lg-6">
							<div class="banner_section_content text-center text-lg-start">
								<p class="sub_title"><?php echo $cre_banner_sub_title ?></p>
								<h1 class="title"> <?php echo $cre_banner_title ?></h1>
								<p class="description"> <?php echo $cre_banner_content ?></p>
							</div>
						</div>
						<div class="col-lg-12 position-relative">
							<div class="banner_logo text-center position-absolute start-0 bottom-0 w-100">
								<h3 class="title"><?php echo $cre_banner_logo_title; ?></h3>
								<div class="swiper banner_logo_slider">
									<div class="swiper-wrapper">
										<?php if (!empty($settings['cre_banner_logo_repeter_item'])) : foreach($settings['cre_banner_logo_repeter_item'] as $item) : ?>
											<div class="swiper-slide">
												<img src="<?php echo $item['cre_logo_img']['url'] ?>" alt="#" class="banner_logo_item">
											</div>
										<?php endforeach; endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
        <?php
		
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
