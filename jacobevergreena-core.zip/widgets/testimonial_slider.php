<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_testimonial_slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-testimonial-slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Testimonial Slider', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	public function get_script_depends() {
        return array('testimonial', 'swiper');
    }

	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_testimonial_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'cre_testimonial_star_review', [
				'label' => __('Rating', 'scooter-companion'),
			    'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'1' => [
						'title' => __('1', 'scooter-companion'),
						'icon' => 'fa fa-star',
					],
					'2' => [
						'title' => __('2', 'scooter-companion'),
						'icon' => 'fa fa-star',
					],
					'3' => [
						'title' => __('3', 'scooter-companion'),
						'icon' => 'fa fa-star',
					],
					'4' => [
						'title' => __('4', 'scooter-companion'),
						'icon' => 'fa fa-star',
					],
					'5' => [
						'title' => __('5', 'scooter-companion'),
						'icon' => 'fa fa-star',
					],
				],
			]
		);

		$repeater->add_control(
			'cre_testimonial_content', [
				'label' => __( 'Content', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'List Content' , 'nanaobiriyeboah-companion' ),
				'show_label' => false,
			]
		);

		$repeater->add_control(
			'cre_client_name', [
				'label' => __( 'Name', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Mark Parker' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'cre_client_position', [
				'label' => __( 'Position', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Real Estate Agent, JUMP Realty' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'cre_testimonial_repeter_item',
			[
				'label' => __( 'Repeater List', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'cre_testimonial_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing 
						elit. Mauris pharetra erat lorem, non accumsan neque pharetra nec. Phasellus eu dolor
						mollis, tempor magna id, accumsan dolor. Praesent quis consectetur turpis. Proin at met.', 
						'nanaobiriyeboah-companion' ),
						'cre_client_name' => __( 'Mark Parker', 'nanaobiriyeboah-companion' ),
					],
				],
				'title_field' => '{{{ cre_client_name }}}',
			]
		);

        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);

        ?>
           <div class="cre_testimonial_section_wrapper">
				<div class="swiper cre_testimonial_slider">
					<div class="swiper-wrapper">
						<?php
							if ( $settings['cre_testimonial_repeter_item'] ) {
								foreach (  $settings['cre_testimonial_repeter_item'] as $item ) {
									?>
									<div class="swiper-slide">
										<div class="testimonial_section_inner">
											<?php
												$star = $item['cre_testimonial_star_review'];
												if (!empty($star)) {
													echo '<div class="cre_rating_star">';
													for ($i = 1; $i <= 5; $i++) {
														if ($star >= $i) {
															echo '<i class="fa fa-star full"></i>';
														} else {
															echo '<i class="fa fa-star"></i>';
														}
													}
													echo '</div>';
												}
											?>
											<?php if(!empty($item['cre_testimonial_content'])): ?>
												<div class="description"> <?php echo $item['cre_testimonial_content'] ?></div>
											<?php endif; ?>

											<div class="client_info_inner">
												<h5 class="name"> <?php echo $item['cre_client_name'] ?></h5>
												<p class="position"> <?php echo $item['cre_client_position'] ?></p>
											</div>
										</div>
									</div>
									<?php
								}
							}
						?>
					</div>
				</div>
				<div class="slider_navigation">
					<div class="swiper-testimonial-prev swiper-prev">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="8.333" viewBox="0 0 20 8.333">
							<path id="Icon" d="M4.167,0,8.333-5.029H5V-20H3.333V-5.029H0Z" transform="rotate(90)" fill="#347455"/>
						</svg>
					</div>
					<div class="swiper-testimonial-next swiper-next">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="8.333" viewBox="0 0 20 8.333">
						    <path id="Icon" d="M4.167,0,8.333-5.029H5V-20H3.333V-5.029H0Z" transform="translate(20 8.333) rotate(-90)" fill="#377356"/>
						</svg>
					</div>
				</div>
           </div>
        <?php
		
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
