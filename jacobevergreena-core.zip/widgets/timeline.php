<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_timeline extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-timeline';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Timeline', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_timeline_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'cre_timeline_icon',
			[
				'label' => esc_html__( 'Check Icon', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-circle',
					'library' => 'fa-solid',
				],
			]
		);
		$repeater->add_control(
			'cre_timeline_icon_shape',
			[
				'label' => esc_html__( 'Choose Shape', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater->add_control(
			'cre_timeline_title', [
				'label' => __( 'Title', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( ' Creative strategy' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'cre_timeline_description',
			[
				'label' => esc_html__( 'Description', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Default description', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your description here', 'textdomain' ),
			]
		);

		$this->add_control(
			'cre_timeline_repeter_item',
			[
				'label' => __( 'Repeater List', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'cre_timeline_title' => __( ' Creative strategy', 'nanaobiriyeboah-companion' ),
					],
				],
				'title_field' => '{{{ cre_timeline_title }}}',
			]
		);

        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		$a = 1;
        ?>
            <div class="cre_timeline_section_wrapper">
				<div class="timeline_inner position-relative">
				<?php
					if ( $settings['cre_timeline_repeter_item'] ) {
						foreach (  $settings['cre_timeline_repeter_item'] as $item ) {
							?>
								<div class="timeline_item">
									<div class="timeline_icon_wrapper position-relative">
										<div class="timeline_icon">
										    <?php \Elementor\Icons_Manager::render_icon( $item['cre_timeline_icon'], [ 'aria-hidden' => 'true' ] ); ?>
										</div>
										<img src="<?php echo $item['cre_timeline_icon_shape']['url'] ?>" alt="#" class="icon_shape">
										<div class="timeline_counter position-absolute">
											<?php echo $a++ ?>
										</div>
									</div>
									
									<div class="timeline_content">
										<h5 class="title"> <?php echo $item['cre_timeline_title'] ?></h5>
										<div class="description">
											<?php echo $item['cre_timeline_description'] ?>
										</div>
									</div>
								</div>
							<?php
						}
					}
				?>
			    </div>
           </div>
        <?php
		
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
