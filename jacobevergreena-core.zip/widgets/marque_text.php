<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_marque_text extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-marque-text';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Marque Text', 'nanaobiriyeboah-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	protected function _register_controls()
    {
        // add content
        $this->_content_control();

        //style section
        $this->_styles_control();
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_marque_text_layout_section',
            [
                'label' => __('Marque Text', 'nanaobiriyeboah-core'),
            ]
        );

        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'cre_marque_text_title', [
				'label' => __( 'Title', 'nanaobiriyeboah-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Sign up' , 'nanaobiriyeboah-core' ),
				'label_block' => true,
			]
		);


		
		$this->add_control(
			'marque_text_repeter_item',
			[
				'label' => __( 'Repeater List', 'nanaobiriyeboah-core' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'cre_marque_text_title' => __( '"Lead-Gen agency"', 'nanaobiriyeboah-core' ),
					],
				],
				'title_field' => '{{{ cre_marque_text_title }}}',
			]
		);


        $this->end_controls_section();
    }

    public function _styles_control(){
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
        ?>
		<div class="marque_text_wrapper">
			<div class="marque_text_inner">
                <?php if ( $settings['marque_text_repeter_item'] ) : foreach (  $settings['marque_text_repeter_item'] as $item ) : ?>
					<div class="dl_marque_text_inner">
                        <h2 class="title"><?php echo $item['cre_marque_text_title']; ?></h2>
					</div>
				<?php endforeach; endif; ?>
			</div>
		</div>
           
        <?php
		
	}
}
