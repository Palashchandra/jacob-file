<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Global_Colors;
use Elementor\Global_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_empower extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-empower';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Empower Box', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-info';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	protected function _register_controls()
    {
        do_action('cre_widgets/animated-image/register_control/start', $this);

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
        do_action('cre_widgets/animated-image/register_control/end', $this);

        // by default
        do_action('cre_widget/section/style/custom_css', $this);
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_pro_animated_image_layout_section',
            [
                'label' => __('Empower Item', 'nanaobiriyeboah-companion'),
            ]
        );

        $this->add_control(
			'empower_thumb',
			[
				'label' => esc_html__( 'Choose Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
            'empower_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => esc_html__('Title', 'nanaobiriyeboah-companion'),
                'default' => esc_html__('Classroom', 'nanaobiriyeboah-companion'),
                'placeholder' => esc_html__('Classroom', 'nanaobiriyeboah-companion'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'empower_des',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => esc_html__('Descriptions', 'nanaobiriyeboah-companion'),
                'default' => esc_html__('Descriptions', 'nanaobiriyeboah-companion'),
                'placeholder' => esc_html__('Descriptions', 'nanaobiriyeboah-companion'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'empower_btn_text',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => esc_html__('Learn More', 'nanaobiriyeboah-companion'),
                'default' => esc_html__('Learn More', 'nanaobiriyeboah-companion'),
                'placeholder' => esc_html__('Learn More', 'nanaobiriyeboah-companion'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

		$this->add_control(
            'empower_btn_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => esc_html__('URL', 'nanaobiriyeboah-companion'),
                'default' => esc_html__('#', 'nanaobiriyeboah-companion'),
                'placeholder' => esc_html__('#', 'nanaobiriyeboah-companion'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_pr_animated_image_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
	
        ?>

        <style>

        </style>

        
            <div class="empower_wrapper_area">
                <div class="empower_item">
                    <?php if (!empty($settings['empower_thumb'])) : ?>
                    <div class="empower_item_thumb">
                        <img src="<?php print esc_url($settings['empower_thumb']['url']); ?>" alt="img">
                    </div>
                    <?php endif; ?>
                    <div class="empower_item_content">
                        <?php if (!empty($settings['empower_title'])) : ?>
                        <h3><?php echo wp_kses_post($settings['empower_title']); ?></h3>
                        <?php endif; ?>
                        <?php if (!empty($settings['empower_des'])) : ?>
                        <p><?php echo wp_kses_post($settings['empower_des']); ?></p>
                        <?php endif; ?>
                        <?php if (!empty($settings['empower_btn_text'])) : ?>
                            <div class="empower_item_btn">
                                <a href="<?php echo esc_url($settings['empower_btn_url']); ?>"><?php echo wp_kses_post($settings['empower_btn_text']); ?> <i class="fas fa-arrow-right"></i></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        <?php
		
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
