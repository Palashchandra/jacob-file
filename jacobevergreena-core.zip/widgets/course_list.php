<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use WP_Query;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_course extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-course';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Course list', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	protected function _register_controls()
    {
        // add content
        $this->_content_control();

    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_course_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

        $this->add_control(
			'cre_course_title', [
				'label' => __( 'Title', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Enterprise Architecture' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);

		$repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'cre_course_menu', [
				'label' => __( 'Menu Item', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Incident management' , 'nanaobiriyeboah-companion' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'cre_course_repeter_item',
			[
				'label' => __( 'Repeater List', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'cre_course_title' => __( ' Creative strategy', 'nanaobiriyeboah-companion' ),
					],
				],
				'title_field' => '{{{ cre_course_title }}}',
			]
		);

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
        ?>
           <div class="cre_course_item_wrapper">
                <!-- <div class="cre_course_item">
                    <h5 class="title">Enterprise Architecture</h5>
                    <ul class="cre_course_menu">
                        <li> <a href="#">Incident management</a></li>
                        <li> <a href="#">Atlassian</a></li>
                        <li> <a href="#">Knowledge management</a></li>
                        <li> <a href="#">Change management</a></li>
                        <li> <a href="#">Freshservice</a></li>
                        <li> <a href="#">TOPdesk</a></li>
                    </ul>
                </div> -->
				<?php
				$args = array(
					'taxonomy' => 'product_cat',
					'orderby' => 'name',
					'order' => 'ASC',
					'hide_empty' => true, // Set to true to hide empty categories
				);
				
				$product_categories = get_terms( $args );
				
				if ( ! empty( $product_categories ) && ! is_wp_error( $product_categories ) ) {
					foreach ( $product_categories as $category ) {
						echo '<div class="cre_course_item">';
						echo '<h5 class="title">' . $category->name . '</h5>';
				
						$category_products = new WP_Query( array(
							'post_type' => 'product',
							'posts_per_page' => -1,
							'tax_query' => array(
								array(
									'taxonomy' => 'product_cat',
									'field' => 'term_id',
									'terms' => $category->term_id,
									'operator' => 'IN',
								),
							),
						) );
				
						if ( $category_products->have_posts() ) {
							echo '<ul class="cre_course_menu">';
							while ( $category_products->have_posts() ) {
								$category_products->the_post();
								echo '<li><a href="'. esc_url(get_permalink()) .'">' . get_the_title() . '</a></li>';
							}
							echo '</ul>';
							wp_reset_postdata(); // Reset post data
						} else {
							echo '<p>No products found in this category.</p>';
						}
						echo '</div>';
					}
				} else {
					echo '<p>No product categories found.</p>';
				}
				
				?>
           </div>
        <?php
		
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
