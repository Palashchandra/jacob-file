<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_tour_list extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-tour-list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Tour List', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	public function get_script_depends() {
        return array('load-more');
    }


	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_tour_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'cre_tour_content_image',
			[
				'label' => __( 'Choose Image', 'elementor' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'cre_tour_title', [
				'label' => __( 'Title', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'Tour Title' , 'nanaobiriyeboah-companion' ),
			]
		);
		$repeater->add_control(
			'cre_tour_content', [
				'label' => __( 'Content', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'Tour Content' , 'nanaobiriyeboah-companion' ),
			]
		);
		$repeater->add_control(
			'banner_btn_1',
			[
				'label' => esc_html__( 'Button 1', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'cre_btn_text_1',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
			]
		);

		$repeater->add_control(
			'cre_btn_url_1',
			[
				'label' => __( 'Button Link', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'nanaobiriyeboah-companion' ),
			]
		);

		$repeater->add_control(
			'banner_btn_2',
			[
				'label' => esc_html__( 'Button 2', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control(
			'cre_btn_text_2',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
			]
		);

		$repeater->add_control(
			'cre_btn_url_2',
			[
				'label' => __( 'Button Link', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'nanaobiriyeboah-companion' ),
			]
		);

		$repeater->add_control(
			'tour_meta_heading_1',
			[
				'label' => esc_html__( 'Age', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'tour_meta_icon_1',
			[
				'label' => esc_html__( 'Icon', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$repeater->add_control(
			'tour_meta_text_1',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
			]
		);
		$repeater->add_control(
			'tour_meta_text_1_color',
			[
				'label' => esc_html__( 'Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tour_meta_list .tour_meta:nth-child(1)' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'tour_meta_text_1_bgcolor',
			[
				'label' => esc_html__( 'Background Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tour_meta_list .tour_meta:nth-child(1)' => 'background-color: {{VALUE}}',
				],
			]
		);

		$repeater->add_control(
			'tour_meta_heading_2',
			[
				'label' => esc_html__( 'Hour', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'tour_meta_icon_2',
			[
				'label' => esc_html__( 'Icon', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$repeater->add_control(
			'tour_meta_text_2',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
			]
		);
		$repeater->add_control(
			'tour_meta_text_2_color',
			[
				'label' => esc_html__( 'Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tour_meta_list .tour_meta:nth-child(2)' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'tour_meta_text_2_bgcolor',
			[
				'label' => esc_html__( 'Background Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tour_meta_list .tour_meta:nth-child(2)' => 'background-color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'tour_meta_heading_3',
			[
				'label' => esc_html__( 'Age', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'tour_meta_icon_3',
			[
				'label' => esc_html__( 'Icon', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$repeater->add_control(
			'tour_meta_text_3',
			[
				'label' => __( 'Button Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Shop Now', 'nanaobiriyeboah-companion' ),
			]
		);
		$repeater->add_control(
			'tour_meta_text_3_color',
			[
				'label' => esc_html__( 'Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tour_meta_list .tour_meta:nth-child(3)' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'tour_meta_text_3_bgcolor',
			[
				'label' => esc_html__( 'Background Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tour_meta_list .tour_meta:nth-child(3)' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'cre_tour_repeter_item',
			[
				'label' => __( 'Repeater List', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'cre_tour_title' => __( 'Scooter Trikes Adventures', 'nanaobiriyeboah-companion' ),
						'cre_tour_content' => __( 'In-City Wheels fat tire Scooters are one the best ways 
						to see all of the sights in Dallas. They’re safe, stable, and easy to ride. These 
						scooters are also a bit faster so be able to quickly zip and tour through the city of Dallas.' ),
					],
				],
				'title_field' => '{{{ cre_tour_title }}}',
			]
		);

		$this->add_control(
			'tour_load_more_text',
			[
				'label' => __( 'Load More Text', 'nanaobiriyeboah-companion' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Load More', 'nanaobiriyeboah-companion' ),
				'placeholder' => __( 'Load More', 'nanaobiriyeboah-companion' ),
			]
		);

        
        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);

        ?>
           <div class="cre_tour_section_wrapper">
				<?php
					if ( $settings['cre_tour_repeter_item'] ) {
						foreach (  $settings['cre_tour_repeter_item'] as $item ) {
							?>
							<div class="tour_section_inner elementor-repeater-item-<?php echo $item['_id'] ?>">
								<div class="container-fluid">
									<div class="row">
										<div class="col-lg-6">
											<div class="tour_secion_content">
												<h4 class="title"><?php echo $item['cre_tour_title'] ?></h4>
										     	<?php echo $item['cre_tour_content'] ?>
										 		<div class="tour_secion_btn d-flex flex-wrap align-items-center">
												    <?php if(!empty($item['cre_btn_text_1'])) :
														echo '<a class="cu_btn base_btn" href="' . $item['cre_btn_url_1']['url'] . '">'. esc_html($item['cre_btn_text_1']) .'</a>';
													endif; ?>
												    <?php if(!empty($item['cre_btn_text_2'])) :
														echo '<a class="cu_btn btn_3" href="' . $item['cre_btn_url_2']['url'] . '">'. esc_html($item['cre_btn_text_2']) .'</a>';
													endif; ?>
												</div>
											</div>
										</div>
										<div class="col-lg-6">
											<div class="tour_secion_img_content">
											    <img src="<?php echo esc_url($item['cre_tour_content_image']['url']) ?>" alt="#" class="img-fluid">
										 		<div class="tour_meta_list">
													<div class="tour_meta">
														<?php if( !empty($item['tour_meta_icon_1'])) : ?>
															<?php \Elementor\Icons_Manager::render_icon( $item['tour_meta_icon_1'], [ 'aria-hidden' => 'true' ] ); ?>
														<?php endif; ?>
														<?php echo esc_html($item['tour_meta_text_1']); ?> 
													</div>
													<div class="tour_meta">
														<?php if( !empty($item['tour_meta_icon_2'])) : ?>
															<?php \Elementor\Icons_Manager::render_icon( $item['tour_meta_icon_2'], [ 'aria-hidden' => 'true' ] ); ?>
														<?php endif; ?>
														<?php echo esc_html($item['tour_meta_text_2']); ?> 
													</div>
													<div class="tour_meta">
														<?php if( !empty($item['tour_meta_icon_3'])) : ?>
															<?php \Elementor\Icons_Manager::render_icon( $item['tour_meta_icon_3'], [ 'aria-hidden' => 'true' ] ); ?>
														<?php endif; ?>
														<?php echo esc_html($item['tour_meta_text_3']); ?> 
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								
							</div>
							<?php
						}
					}
				?>
           </div>
		   <?php if(!empty($tour_load_more_text)) : ?>
			<div class="text-center">
					<a href="#" class="cu_btn load_more_btn"> <?php echo $tour_load_more_text ?></a>
				</div>
		    <?php endif; ?>

			
        <?php
		
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
