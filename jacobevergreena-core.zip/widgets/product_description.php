<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_product_description extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-product-description';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Poduct  Description', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}


	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_product_description_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );
		
        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
        global $product;

        // $product = array(
        //     'post_type' => 'product',
        //     'posts_per_page' => 3,
        //     'orderby' => 'meta_value_num', 
        //     'order' => 'DESC'
        // );
        // $product_list = new WP_Query( $product );

        ?>
            <div class="cre_product_section_wrapper">

                <?php echo the_title(); ?>

                <h5 class="title"><?php echo $Wheel_driv; ?></h5>
                <?php print_r($product); ?>

                <!-- <?php if ( $product_list->have_posts() ) : while ( $product_list->have_posts() ) : $product_list->the_post() ?>
                    <?php
                        $Wheel_drive1 = function_exists('get_field') ? get_field('wheel_drive') : '';
                        
                    ?>
                    <div class='product_meta'>
                        <?php if(!empty($Wheel_drive1)) { ?>
                            <div class="product_meta_item">
                                <h5 class="title"><?php echo $Wheel_drive1; ?></h5>
                            </div>
                        <?php }?>
                    </div>
                <?php endwhile; endif; ?> -->

                
            </div>
        <?php
		
	}
	
}
