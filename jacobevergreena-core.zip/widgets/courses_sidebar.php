<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_courses_sidebar extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-courses-sidebar';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Courses Sidebar', 'randrcons-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'randrcons' ];
	}

	protected function _register_controls()
    {
        // add content
        $this->_content_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_all_course_filter_section',
            [
                'label' => __('Content', 'randrcons-companion'),
            ]
        );

		$this->add_control(
			'all_course_filter_title',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'Filters', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your description here', 'textdomain' ),
			]
		);
		$this->add_control(
            'filter_icon',
            [
                'label' => __( 'Icon', 'hdoctor-core' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'ti-arrow-right',
                    'library' => 'solid',
                ],
            ]
        );
		$this->add_control(
			'all_course_filter_dis',
			[
				'label' => esc_html__( 'Discription', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Current selected course: 152 ', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your description here', 'textdomain' ),
				'label_block' => true,
			]
		);
        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		?>
		<div class="all_course_sidebar">
			<div class="filter_btn">
				<h4 class="title"> <?php echo $all_course_filter_title; ?><?php \Elementor\Icons_Manager::render_icon( $settings['filter_icon'], [ 'aria-hidden' => 'true' ] ); ?></h4>
				<p>
					<?php echo $all_course_filter_dis; ?>
				</p>
			</div>
			<?php
			function generate_taxonomy_checkboxes($taxonomy) {
				$args = array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => true,
				);

				$categories = get_categories($args);

				foreach ($categories as $category) {
					$category_id = $category->term_id;
					$category_posts = get_posts(array(
						'post_type' => 'post',
						'tax_query' => array(
							array(
								'taxonomy' => $taxonomy,
								'field'    => 'term_id',
								'terms'    => $category_id,
							),
						),
					));

					if (!empty($category_posts)) {
						echo '<div class="check_item"><label>';
						echo '<input type="checkbox" name="' . esc_attr($taxonomy) . '[]" value="' . esc_attr($category_id) . '">';
						echo $category->name;
						echo '</label></div>';
					}
				}
			}
			?>
			<div class="co_filter_inner">
				<div class="sidebar_item sidebar_dropdown">
					<div class="dropdown_title"> <h4>Categories</h4><i class="fas fa-sort-down"></i></div>
					<div class="dropdown_content" id="post-category-list">
						<?php generate_taxonomy_checkboxes('category'); ?>
					</div>
				</div>

				<div class="sidebar_item sidebar_dropdown">
					<div class="dropdown_title"> <h4>Topic</h4><i class="fas fa-sort-down"></i></div>
					<div class="dropdown_content" id="post-topic-list">
						<?php generate_taxonomy_checkboxes('topic'); ?>
					</div>
				</div>

				<div class="sidebar_item sidebar_dropdown">
					<div class="dropdown_title"> <h4>Provider</h4><i class="fas fa-sort-down"></i></div>
					<div class="dropdown_content" id="post-provider-list">
						<?php generate_taxonomy_checkboxes('provider'); ?>
					</div>
				</div>
			</div>
        </div>
		<script>
			jQuery(document).ready(function ($) {
				const loadCategoryData = (page, append) => {

					const postOrder = $('#post-order').val();

					const categoryIds = $('input[name="categorie[]"]:checked').map(function () {
						return $(this).val();
					}).get();
					
					const topicIds = $('input[name="topic[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const providerIds = $('input[name="provider[]"]:checked').map(function () {
						return $(this).val();
					}).get();

					const advancedIds = $('input[name="advanced[]"]:checked').map(function () {
						return $(this).val();
					}).get();


					const searchInput = $('#post-search').val();

					const data = {
						action: 'post_widget_ajax',
						fee: categoryIds,
						topic: topicIds,
						provider: providerIds,
					};

					$.ajax({
						url: '<?php echo admin_url("admin-ajax.php") ?>',
						type: 'POST',
						data: data,					
						success: (response) => {
							response.append ? $('#post-list').append(response.data) : $('#post-list').html(response.data);							
							if( response.page ) {
								$('.load-more-co-stars').attr('data-page', response.page).show();
							} else {
								$('.load-more-co-stars').attr('data-page', response.page).hide();
							}
						},
					});
				};

				// Initial load with all posts
				loadCategoryData( 1, '' );

				$('.sidebar_dropdown input').on('change', function() {
					loadCategoryData(1, '');
				});


				$('.load-more-co-stars').on('click', function(e) {
					e.preventDefault();
					const page = $(this).data('page');
					loadCategoryData(page, 'append');
				});
				
				function filter_dropdown_two() {
					if ($(window).width() < 992 ) {
						$(".all_course_sidebar .filter_btn").on("click", function (event) {
						$(this).parent().find(".co_filter_inner").first().toggle(700);
						$(this).toggleClass("active");
						});
					}
				}
				filter_dropdown_two();
			});

		</script>
        <?php
        
		
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}