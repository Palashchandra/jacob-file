<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_reel extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-reel';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'reel', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}

	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        $this->start_controls_section(
            'repeater_section',
            [
                'label' => __('Repeater Items', 'your-text-domain'),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'video_url',
            [
                'label' => __('Video URL', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://www.youtube.com/watch?v=example', 'your-text-domain'),
                'show_external' => true,
                'default' => [
                    'url' => '',
                ],
            ]
        );

		$repeater->add_control(
			'video_thumb',
			[
				'label' => esc_html__( 'Video thumbnail', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'video_popup_icon',
			[
				'label' => esc_html__( 'Icon', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-circle',
					'library' => 'fa-solid',
				]
			]
		);

        $repeater->add_control(
            'video_url',
            [
                'label' => __('Video URL', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://www.youtube.com/watch?v=example', 'your-text-domain'),
                'show_external' => true,
                'default' => [
                    'url' => '',
                ],
            ]
        );

        $repeater->add_control(
            'popup_text_block_1',
            [
                'label' => __('Text Block 1', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __('Default WYSIWYG 1', 'your-text-domain'),
            ]
        );

        $repeater->add_control(
            'popup_text_block_2',
            [
                'label' => __('Text Block 2', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __('Default WYSIWYG 1', 'your-text-domain'),
            ]
        );

        $repeater->add_control(
            'popup_text_block_3',
            [
                'label' => __('Text Block 3', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __('Default WYSIWYG 1', 'your-text-domain'),
            ]
        );


        $this->add_control(
            'popup_repeater_items',
            [
                'label' => __('Repeater Items', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
            ]
        );

        $this->end_controls_section();
    }

    public function _styles_control(){

        $this->start_controls_section(
            '_cre_style_section',
            [
                'label' => esc_html__('Style', 'nanaobiriyeboah-companion'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

            ]
        );

        
        $this->end_controls_section();
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$popup_repeater_items = $settings['popup_repeater_items'];
		$a = 0;
		$b = 0;
		?>
		<!-- Button trigger modal -->
		
		<div class="reel_part_wrapper">
			<?php
			 foreach ($popup_repeater_items as $item) {
				?>
				<div class="reel_part_item position-relative" data-bg-img="<?php echo $item['video_thumb']['url'] ?>">
					<button type="button" class="btn btn-primary position-absolute top-50 start-50 translate-middle" data-bs-toggle="modal" data-bs-target="#Modal<?php echo $a++ ?>">
					    <?php \Elementor\Icons_Manager::render_icon( $item['video_popup_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					</button>
				</div>
				<?php
			}
			?>
		</div>

		<!-- Modal -->
		<div class="reel_modal_wrapper">
			<?php
				foreach ($popup_repeater_items as $item) {
					?>
					<div class="modal fade" id="Modal<?php echo $b++ ?>" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
							<div class="modal-content">
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
								<video src="<?php echo $item['video_url']['url'] ?>" class="object-fit-contain" controls></video>
								<div class="row">
									<div class="col-lg-12">
										<div class="modal_text_block">
											<?php echo $item['popup_text_block_1']; ?>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="modal_text_block">
											<?php echo $item['popup_text_block_2']; ?>
										</div>
									</div>
									<div class="col-lg-6">
									<div class="modal_text_block">
											<?php echo $item['popup_text_block_3']; ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php
				}
			?>
		</div>
		
		
		<?php
       
	}
	

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
	}
}
