<?php
namespace nanaobiriyeboahcompanion\Widgets;

use Elementor\Widget_Base;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class nanaobiriyeboah_portfolio_filter extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'nanaobiriyeboah-portfolio-filter';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Portfolio Filter', 'nanaobiriyeboah-companion' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'nanaobiriyeboah' ];
	}


	protected function _register_controls()
    {

        // add content
        $this->_content_control();
        
        //style section
        $this->_styles_control();
        
    }

    public function _content_control(){
        //start subscribe layout
        $this->start_controls_section(
            '_cre_portfolio_filter_section',
            [
                'label' => __('Content', 'nanaobiriyeboah-companion'),
            ]
        );

        
        
        $this->end_controls_section();
    }

    public function _styles_control(){
        
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		$portfolio = get_terms(array(
			'post_type' => 'portfolio',
			'taxonomy' => 'category', // Replace with your actual taxonomy name
			'hide_empty' => true,
		));

		$portfolio_item = array(
            'post_type' => 'portfolio',
            'posts_per_page' => -1, 
            'order' => 'DESC'
        );
        $portfolio_list = new WP_Query( $portfolio_item );
        ?>
			<div class="portfolio_list_wrapper">
				<div class="portfolio_fitrow_filter">
					<button data-filter="*" class="active">show all</button>
					<?php
						if (!empty($portfolio)) {
							foreach ($portfolio as $category) {
								echo '<button data-filter=".' . esc_html($category->slug) . '">' . esc_html($category->name) . '</button>';
							}
						}
					?>
				</div>
				<div class="portfolio_list_fitrow grid">
					<div class="grid-sizer"></div>
					<?php 
						if($portfolio_list -> have_posts()) : while($portfolio_list -> have_posts()) : $portfolio_list -> the_post() ;
						$post_id = get_the_ID();
						$taxonomy = 'category';
						$terms = get_the_terms($post_id, $taxonomy);
						$category_slug = '';
						if ($terms && !is_wp_error($terms)) {
							$category_slugs = wp_list_pluck($terms, 'slug');
							$category_slug = implode(' ', $category_slugs);
						}
						$box_size = get_field('box_size');
					?>
						<div class="single_portfolio_item grid-item <?php echo esc_attr($category_slug).' '. esc_attr($box_size) ?>">
							<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#" class="mas_img">
							<div class="portfolio_iner_content">
								<h3 class="title"> 
									<?php the_title(); ?>
								</h3>
							</div>
					    </div>
					<?php endwhile; endif; ?>
					<?php wp_reset_postdata(); ?>
				</div>
	        </div>
        <?php
	}
	
}
