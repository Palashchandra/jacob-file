;(function($){
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/nanaobiriyeboah-testimonial-slider.default',function(scope,$){
            $(scope).find(".cre_card_slider").each(function () {
                var swiper = new Swiper('.cre_card_slider', {
                    // direction: "vertical",
                    // freeMode: true,
                    slidesPerView: 1,
                    mousewheel: true,
                    allowTouchMove: 1,
                    loop: true,
                    speed: 1000,
                    autoplay: false,
                    autoplay: {
                        delay: 3000,
                    },
                });
            });
        });
    });
})(jQuery);