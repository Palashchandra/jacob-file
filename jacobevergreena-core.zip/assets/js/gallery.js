;(function($){
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/nanaobiriyeboah-testimonial-slider.default',function(scope,$){
            $(scope).find('.cre_gallery_grid').isotope({
                itemSelector: '.grid-item',
                percentPosition: true,
                masonry: {
                    columnWidth: '.grid-sizer'
                }
            });
        });
    });
})(jQuery);