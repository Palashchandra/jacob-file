;(function($){
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/nanaobiriyeboah-tour-list.default',function(scope,$){
            $(scope).find(".cre_tour_section_wrapper").each(function () {
                $(".tour_section_inner").slice(0, 2).show();
                $(".load_more_btn").on("click", function(e){
                    e.preventDefault();
                    $(".tour_section_inner:hidden").slice(0, 1).slideDown();
                    if($(".tour_section_inner:hidden").length == 0) {
                        $(".load_more_btn").text("No Content").addClass("d-none");
                    }
                });
            });
        });
    });
})(jQuery);