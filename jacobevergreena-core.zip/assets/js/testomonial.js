;(function($){
    $(window).on('elementor/frontend/init',function(){
        elementorFrontend.hooks.addAction('frontend/element_ready/nanaobiriyeboah-testimonial-slider.default',function(scope,$){
            $(scope).find(".swiper-container").each(function () {
                var t = $(this),
                    i = ($(this).attr("id"), $(this).data("perpage") || 1),
                    a = $(this).data("loop"),
                    o = $(this).data("space") || 0,
                    l = $(this).data("effect"),
                    c = $(this).data("center"),
                    pl = $(this).data("autoplay"),
                    nex = $(this).data("next"),
                    pre = $(this).data("prev"),
                    pag = $(this).data("pagination"),
                    pagtype = $(this).data("paginationtype"),
                    d = $(this).data("direction") || "horizontal",
                    r = $(this).data("breakpoints");
                new Swiper(t, {
                    slidesPerView: i,
                    direction: d,
                    spaceBetween: o,
                    loop: a,
                    effect: l,
                    speed: 1000,
                    breakpoints: r,
                    centeredSlides: c,
                    autoplay: pl,
                    autoplay: {
                        delay: 1000000,
                        disableOnInteraction: !1
                    },
                    pagination: {
                        el: pag,
                        type: pagtype,
                        clickable: !0
                    },
                    navigation: {
                        nextEl: nex,
                        prevEl: pre
                    }
                })
            });
            $(".swiper-container").hover(function () {
                (this).swiper.autoplay.stop();
            }, function () {
                (this).swiper.autoplay.start();
            });
        });
    });
})(jQuery);