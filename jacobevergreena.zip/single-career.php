<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nanaobiriyeboah
 */

get_header();

?>

	<main id="primary" class="site-main">
		<?php
		
		get_template_part('template-parts/banner/banner-post', 'single');


		while ( have_posts() ) :
			the_post();

            the_content();
			 

		endwhile; // End of the loop.
		wp_reset_postdata(  );
		
		?>
	</main><!-- #main -->

<?php

get_footer();
