<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package nanaobiriyeboah
 */

get_header();
$text_boxes = get_field('text_boxes');

?>

	<main id="primary" class="site-main">
		<?php
		get_template_part('template-parts/banner/banner-post', 'single');
		?>
		<div class="site-single-blog">
			<div class="container">
				<div class="row">
					<?php while ( have_posts() ) : the_post(); ?>
						<div class="single-post-thumb">
							<?php 
								if ( has_post_thumbnail() ) {
									the_post_thumbnail();
								}
							?>
						</div>
						
						<div class="post-meta">
							<p class="category"><?php the_category(', '); ?></p>
							<p class="date"><?php the_date(); ?></p>
						</div>

						<h3 class="small-title"><?php the_title(); ?></h3>
						
						<?php if(!empty($text_boxes)) : foreach ($text_boxes as $single_box) : ?>
						<?php
						// Assuming $choose_style is fetched for each $single_box
						$choose_style = $single_box['choose_style'];
						$text_box_title = $single_box['text_box_title'];
						$text_box_description = $single_box['text_box_description'];
						$image_gallery = $single_box['image_gallery'];
						$single_image = $single_box['single_image'];

						// Check the selected value and display content accordingly
						if ($choose_style === 'Full Width') {
							// Display content for the full width row
							?>
							<div class="single-content-boxes">
								<div class="row">
									<div class="col-lg-12">
										<h4><?php echo $text_box_title; ?></h4>
										<?php echo $text_box_description; ?>
									</div>
								</div>
								<?php if ($image_gallery) : ?>
								<div class="row mt-2 gy-4">
									<!-- Image gallery -->
									<?php foreach ($image_gallery as $image) : ?>
										<div class="col-lg-6"> <!-- Adjust the column width as needed -->
											<img class="img-fluid" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
										</div>
									<?php endforeach; ?>
								</div>
								<?php endif; ?>
							</div>
							<?php
						} elseif ($choose_style === 'Two Column') {
							// Display content for the two column row
							?>
							<div class="single-content-boxes">
								<div class="row">
									<div class="col-lg-6">
										<h4><?php echo $text_box_title; ?></h4>
										<?php echo $text_box_description; ?>
									</div>
									<div class="col-lg-6">
										<img class="img-fluid" src="<?php echo $single_image; ?>" alt="">
									</div>
								</div>
							</div>
							<?php
						}
						?>
					<?php endforeach; endif; ?>

					<?php
					endwhile; // End of the loop.
					wp_reset_postdata(  );
					?>
				</div>
			</div>
		</div>
	</main><!-- #main -->

<?php

get_footer();
