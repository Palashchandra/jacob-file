<?php 
/**
 * Enqueue scripts and styles.
 */
function nanaobiriyeboah_scripts() {
	wp_enqueue_style( 'nanaobiriyeboah-style', get_stylesheet_uri(), array(), nanaobiriyeboah_VERSION );
	wp_enqueue_style( 'bootstarp-css', nanaobiriyeboah_CSS.'/bootstarp.css', array( 'nanaobiriyeboah-style' ), nanaobiriyeboah_VERSION );
	wp_enqueue_style( 'fontawesome', nanaobiriyeboah_CSS.'/all.min.css', array( 'nanaobiriyeboah-style' ), nanaobiriyeboah_VERSION );
	wp_enqueue_style( 'magnific-popup', nanaobiriyeboah_CSS.'/magnific-popup.css', array( 'nanaobiriyeboah-style' ), nanaobiriyeboah_VERSION );
	wp_enqueue_style( 'nanaobiriyeboah-animate', nanaobiriyeboah_CSS.'/animate.css', array( 'nanaobiriyeboah-style' ), nanaobiriyeboah_VERSION );
	wp_enqueue_style( 'swiper', nanaobiriyeboah_vendor_CSS.'/swiper/swiper-bundle.min.css', array( 'nanaobiriyeboah-style' ), nanaobiriyeboah_VERSION );
	wp_enqueue_style( 'nanaobiriyeboah-style-main', get_theme_file_uri('/assets/css/style.css'), array(), nanaobiriyeboah_VERSION );


	//  Enqueue script   
	wp_enqueue_script( 'bootstarp-js', nanaobiriyeboah_JS. '/bootstarp.js', array('jquery'), nanaobiriyeboah_VERSION, true );
	wp_enqueue_script( 'mediaelement-and-player', nanaobiriyeboah_JS. '/mediaelement-and-player.min.js', array('jquery'), nanaobiriyeboah_VERSION, true );
	wp_enqueue_script( 'magnific-popup', nanaobiriyeboah_JS. '/jquery.magnific-popup.js', array('jquery'), nanaobiriyeboah_VERSION, true );
	wp_enqueue_script( 'nanaobiriyeboah-parallax-scroll', nanaobiriyeboah_vendor_JS . '/parallax/jquery.parallax-scroll.js', array(), nanaobiriyeboah_VERSION, true );
	wp_enqueue_script( 'nanaobiriyeboah-wow', nanaobiriyeboah_JS . '/wow.min.js', array(), nanaobiriyeboah_VERSION, true );
	wp_enqueue_script( 'swiper-theme', nanaobiriyeboah_vendor_JS . '/swiper/swiper-bundle.min.js', array(), nanaobiriyeboah_VERSION, true );
	wp_enqueue_script( 'nanaobiriyeboah-main', nanaobiriyeboah_JS . '/main.js', array('jquery'), nanaobiriyeboah_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script('comment-reply');
	}
		
}
add_action('wp_enqueue_scripts', 'nanaobiriyeboah_scripts');