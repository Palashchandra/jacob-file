<?php 


require nanaobiriyeboah_THEMEROOT_DIR . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require nanaobiriyeboah_THEMEROOT_DIR . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require nanaobiriyeboah_THEMEROOT_DIR . '/inc/template-functions.php';
/**
 * nanaobiriyeboah helper 
 */
require nanaobiriyeboah_THEMEROOT_DIR . '/inc/helper.php';

/**
 * nanaobiriyeboah comment area
*/
require nanaobiriyeboah_THEMEROOT_DIR.'/inc/classes/comment_walker.php';
/**
 * nanaobiriyeboah nav walker
*/
require nanaobiriyeboah_THEMEROOT_DIR.'/inc/classes/main-nav-walker.php';
/**
 * Customizer additions.
 */
require nanaobiriyeboah_THEMEROOT_DIR . '/inc/customizer.php';

/**
 * nanaobiriyeboah Enqueue 
 */

require nanaobiriyeboah_THEMEROOT_DIR . '/inc/static_enqueue.php';


/**
 * nanaobiriyeboah breadcrumbs
 */

require nanaobiriyeboah_THEMEROOT_DIR . '/inc/breadcrumbs.php';

/**
 * nanaobiriyeboah Tgm
 */
require nanaobiriyeboah_THEMEROOT_DIR . '/inc/plugin_activation.php';


/**
 * nanaobiriyeboah ajax
 */
require nanaobiriyeboah_THEMEROOT_DIR . '/inc/ajax/blog.php';
require nanaobiriyeboah_THEMEROOT_DIR . '/inc/ajax/search.php';
require nanaobiriyeboah_THEMEROOT_DIR . '/inc/ajax/product.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require nanaobiriyeboah_THEMEROOT_DIR . '/inc/jetpack.php';
}
