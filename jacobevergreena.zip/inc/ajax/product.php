<?php

//product filter ajax function
function product_widget_ajax_callback() {
    $category = isset($_POST['category']) ? $_POST['category'] : null;
    $topic = isset($_POST['topic']) ? $_POST['topic'] : null;
    $provider = isset($_POST['provider']) ? $_POST['provider'] : null;
    $post_tag = isset($_POST['post_tag']) ? $_POST['post_tag'] : null;
    $level = isset($_POST['level']) ? $_POST['level'] : null;
    $delivery_format = isset($_POST['delivery_format']) ? $_POST['delivery_format'] : null;
    $paged =  isset($_POST['paged']) ? str_replace('?paged=', '', $_POST['paged']) : 1;
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 8,
        'paged' => $paged,
    );

    // Create a tax_query to handle 'category', 'topic', 'provider', and 'post_tag'
    $tax_query = array('relation' => 'AND'); // Initialize tax_query with 'AND' relation

    if (!empty($category)) {
        $tax_query[] = array(
            'taxonomy' => 'category',
            'field' => 'id',
            'terms' => $category,
        );
    }

    if (!empty($topic)) {
        $tax_query[] = array(
            'taxonomy' => 'topic',
            'field' => 'id',
            'terms' => $topic,
        );
    }

    if (!empty($provider)) {
        $tax_query[] = array(
            'taxonomy' => 'provider',
            'field' => 'id',
            'terms' => $provider,
        );
    }

    if (!empty($post_tag)) {
        $tax_query[] = array(
            'taxonomy' => 'post_tag',
            'field' => 'id',
            'terms' => $post_tag,
        );
    }

    if (!empty($level)) {
        $tax_query[] = array(
            'taxonomy' => 'level',
            'field' => 'id',
            'terms' => $level,
        );
    }

    if (!empty($delivery_format)) {
        $tax_query[] = array(
            'taxonomy' => 'delivery_format',
            'field' => 'id',
            'terms' => $delivery_format,
        );
    }

    if (!empty($tax_query)) {
        $args['tax_query'] = $tax_query;
    }

    $products = new WP_Query($args);

    ob_start();
    if ($products->have_posts()) {
        while ($products->have_posts()) {
            $products->the_post();
            $product_id = get_the_ID(); // Replace 123 with your actual product ID
            $product = wc_get_product($product_id); // Get the product object
            global $product;
            ?>
            <div class="cre_course_items">
                <h5 class="title"><?php echo the_title(); ?></h5>
                <div class="course_details_content">
                    <ul class="cre_course_details">
                        <li><span>Duration:</span>5 Days</li>
                        <li><span>Exam:</span>AZ-800</li>
                        <li><span>Language:</span>English</li>
                        <li><span>Level:</span>Fundamental</li>
                    </ul>
                    <div class="add-to-cart">
                        <?php 
                        $args = array(
                            'quantity'   => 1,
                            'class'      => implode( ' ', array_filter( array(
                                'course_add_cart',
                                'product_type_' . $product->get_type(),
                                $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
                                $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
                            ) ) ),
                        );
        
                        woocommerce_template_loop_add_to_cart($args);
                        ?>
                    </div>
                    <div class="d-flex course_meta">
                       <a href="#" class="course_details_btn course_price" data-product-id="<?php echo get_the_ID(); ?>">
                            <span class="ch_btn_text">See Price <i class="fas fa-arrow-right"></i></span>
                            <span class="ch_price">
                                <?php
                                    if ($product) {
                                        $display_price = $product->get_price();
                                        echo 'Price: ' . wc_price($display_price);
                                    }
                                ?>
                            </span>
                        </a>
                        <a href="<?php echo get_the_permalink(); ?>" class="course_details_btn">Dates & Details<i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <?php
        }
        wp_reset_postdata();
        echo '<div class="pagination">';
        echo paginate_links(array(
            'total' => $products->max_num_pages,
			'format' => '?paged=%#%',
	        'current' => $paged,
			'prev_text' => '<i class="fas fa-chevron-left"></i>',
            'next_text' => '<i class="fas fa-chevron-right"></i>',
        ));
        echo '</div>';
    } else {
        echo 'No posts found.';
    }
    $output = ob_get_clean();

    wp_send_json($output);

    wp_reset_postdata();

    wp_die();
}

add_action('wp_ajax_product_widget_ajax', 'product_widget_ajax_callback');
add_action('wp_ajax_nopriv_product_widget_ajax', 'product_widget_ajax_callback');

