<?php

function filter_posts_callback() {
    $taxonomies = isset($_POST['taxonomies']) ? $_POST['taxonomies'] : array();

    $args = array(
        'post_type' => 'product',
        'tax_query' => array(),
    );

    foreach ($taxonomies as $taxonomy => $term_ids) {
        $args['tax_query'][] = array(
            'taxonomy' => $taxonomy,
            'field'    => 'term_id',
            'terms'    => $term_ids,
            'operator' => 'IN',
        );
    }

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            // Output the post content or customize as needed
            echo '<h2>' . get_the_title() . '</h2>';
            the_content();
        }
        wp_reset_postdata();
    } else {
        echo 'No posts found.';
    }

    die(); // Always end with die() to prevent extra output
}
add_action('wp_ajax_filter_posts', 'filter_posts_callback');
add_action('wp_ajax_nopriv_filter_posts', 'filter_posts_callback'); // Allow AJAX for non-logged in users



