<?php

//blog filter ajax function
function post_widget_ajax_callback() {
    $category = isset($_POST['category']) ? $_POST['category'] : null;
    $topic = isset($_POST['topic']) ? $_POST['topic'] : null;
    $provider = isset($_POST['provider']) ? $_POST['provider'] : null;
    $post_tag = isset($_POST['post_tag']) ? $_POST['post_tag'] : null;
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

    $args = array(
        'post_type' => 'any',
        'posts_per_page' => 4,
        'paged' => $paged,
        's' => get_search_query(),
    );

    // Create a tax_query to handle 'category', 'topic', 'provider', and 'post_tag'
    $tax_query = array('relation' => 'AND'); // Initialize tax_query with 'AND' relation

    if (!empty($category)) {
        $tax_query[] = array(
            'taxonomy' => 'category',
            'field' => 'id',
            'terms' => $category,
        );
    }

    if (!empty($topic)) {
        $tax_query[] = array(
            'taxonomy' => 'topic',
            'field' => 'id',
            'terms' => $topic,
        );
    }

    if (!empty($provider)) {
        $tax_query[] = array(
            'taxonomy' => 'provider',
            'field' => 'id',
            'terms' => $provider,
        );
    }

    if (!empty($post_tag)) {
        $tax_query[] = array(
            'taxonomy' => 'post_tag',
            'field' => 'id',
            'terms' => $post_tag,
        );
    }

    if (!empty($tax_query)) {
        $args['tax_query'] = $tax_query;
    }

    $query = new WP_Query($args);

    ob_start();
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            ?>
            <div class="blog_post_item">
                <?php if(!empty(get_the_post_thumbnail_url())) : ?>
                    <a href="<?php echo get_the_permalink(); ?>" class="post_thumb">
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#" class="img-fluid">
                    </a>
                <?php endif; ?>
                
                <div class="post_content">
                    <div class="post_meta">
                        <?php 
                            $categories = get_the_category();
                            if ($categories) {
                                // Get the first category from the array
                                $first_category = $categories[0];
                                
                                // Output the first category name with the static "5 min read" span tag
                                echo '<p>' . esc_html($first_category->name) . ' <span>5 min read</span></p>';
                            }
                        ?>
                        <p class="post-date">
                            <?php echo get_the_date('j M, Y'); ?>
                        </p>
                    </div>
                    <h5 class="title"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
                    <p class="description"><?php echo wp_trim_words(get_the_excerpt(), 10, '....'); ?></p>
                    <a href="<?php echo get_the_permalink(); ?>" class="read_more">Read More <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <?php
        }
        echo '<div class="pagination">';
        echo paginate_links(array(
            'total' => $query->max_num_pages,
			'format' => '?paged=%#%',
	        'current' => max( 1, get_query_var('paged') ),
			'prev_text' => '<i class="fas fa-chevron-left"></i>',
            'next_text' => '<i class="fas fa-chevron-right"></i>',
        ));
        echo '</div>';
    } else {
        echo 'No posts found.';
    }
    $output = ob_get_clean();

    wp_send_json($output);

    wp_reset_postdata();

    wp_die();
}

add_action('wp_ajax_post_widget_ajax', 'post_widget_ajax_callback');
add_action('wp_ajax_nopriv_post_widget_ajax', 'post_widget_ajax_callback');
