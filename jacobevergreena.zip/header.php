<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package nanaobiriyeboah
 */
$popup_title = nanaobiriyeboah_options('popup_title');
$popup_description = nanaobiriyeboah_options('popup_description');
$list_title = nanaobiriyeboah_options('list_title');
$popup_functionality = nanaobiriyeboah_options('popup_functionality');

?>

<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- cookis popup end -->
<div class="overlay" id="overlay"></div>
<div class="cookie-popup top-50 start-50 translate-middle" id="cookiePopup">
	<div class="popup_content_wrapper">
		<h3 class="title"><?php echo $popup_title ?></h3>
		<p class="description"><?php echo $popup_description ?></p>
		<h5 class="sub_title"><?php echo $list_title ?></h5>
		<div class="functionality_list"><?php echo $popup_functionality ?></div>
	</div>
	<div class="popup_button_list">
		<button class="c_accept_btn">Accept Cookies</button>
		<button class="c_decline_btn">Reject All</button>
	</div>
</div>
<!-- cookis popup end -->

<!-- login popup start -->
<div class="ja_modal modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">
                    <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M24.2487 13.5574L19.7612 17.9824L24.2487 22.4074C24.3736 22.5244 24.4732 22.6657 24.5412 22.8226C24.6093 22.9796 24.6444 23.1488 24.6444 23.3199C24.6444 23.491 24.6093 23.6603 24.5412 23.8172C24.4732 23.9742 24.3736 24.1155 24.2487 24.2324C24.1319 24.3483 23.9934 24.4399 23.8411 24.5021C23.6888 24.5643 23.5257 24.5959 23.3612 24.5949C23.0333 24.5935 22.7191 24.4634 22.4862 24.2324L17.9987 19.7449L13.5737 24.2324C13.3409 24.4634 13.0267 24.5935 12.6987 24.5949C12.5342 24.5959 12.3712 24.5643 12.2189 24.5021C12.0666 24.4399 11.928 24.3483 11.8112 24.2324C11.5784 23.9982 11.4477 23.6814 11.4477 23.3512C11.4477 23.0209 11.5784 22.7041 11.8112 22.4699L16.2362 17.9824L11.8112 13.5574C11.6065 13.3183 11.4994 13.0107 11.5116 12.6961C11.5237 12.3815 11.6542 12.0831 11.8768 11.8605C12.0994 11.6379 12.3978 11.5074 12.7124 11.4953C13.027 11.4831 13.3346 11.5901 13.5737 11.7949L17.9987 16.2199L22.4237 11.7949C22.5395 11.6751 22.6777 11.5792 22.8304 11.5128C22.9832 11.4464 23.1476 11.4107 23.3141 11.4078C23.4807 11.4049 23.6462 11.4348 23.8012 11.4959C23.9562 11.557 24.0977 11.648 24.2175 11.7637C24.3373 11.8794 24.4332 12.0176 24.4996 12.1704C24.566 12.3232 24.6017 12.4875 24.6046 12.6541C24.6075 12.8206 24.5776 12.9862 24.5165 13.1412C24.4555 13.2961 24.3645 13.4376 24.2487 13.5574ZM30.3737 30.3574C27.9262 32.8047 24.808 34.4712 21.4134 35.1463C18.0188 35.8214 14.5002 35.4747 11.3026 34.1502C8.10502 32.8256 5.372 30.5825 3.44916 27.7047C1.52631 24.8269 0.5 21.4435 0.5 17.9824C0.5 14.5213 1.52631 11.138 3.44916 8.26014C5.372 5.38231 8.10502 3.1393 11.3026 1.81471C14.5002 0.490123 18.0188 0.14346 21.4134 0.818557C24.808 1.49365 27.9262 3.16019 30.3737 5.60743C31.999 7.23248 33.2882 9.16174 34.1677 11.2851C35.0473 13.4084 35.5 15.6841 35.5 17.9824C35.5 20.2807 35.0473 22.5565 34.1677 24.6798C33.2882 26.8031 31.999 28.7324 30.3737 30.3574ZM28.6112 7.36993C26.5114 5.27735 23.8386 3.85391 20.9303 3.27935C18.022 2.70479 15.0086 3.00488 12.2708 4.14172C9.53293 5.27857 7.19333 7.20118 5.54741 9.66679C3.90149 12.1324 3.02307 15.0304 3.02307 17.9949C3.02307 20.9594 3.90149 23.8575 5.54741 26.3231C7.19333 28.7887 9.53293 30.7113 12.2708 31.8481C15.0086 32.985 18.022 33.2851 20.9303 32.7105C23.8386 32.1359 26.5114 30.7125 28.6112 28.6199C30.0096 27.2264 31.1192 25.5705 31.8763 23.7472C32.6334 21.9239 33.0231 19.9691 33.0231 17.9949C33.0231 16.0207 32.6334 14.0659 31.8763 12.2427C31.1192 10.4194 30.0096 8.76348 28.6112 7.36993Z" fill="#14545E"/>
                    </svg>
                </span>
            </button>
            <div class="modal-body">
                <h2 class="modal-title" id="loginModalLabel">Sign In</h2>
                <p class="description">Explore Over 10,000 Courses: Online, Classroom, and Self-Paced. Each course is designed with excellence...</p>
                <?php echo do_shortcode('[woocommerce_login]') ?>
            </div>
            <div class="modal_footer">
                Don't have an account? Create
                <button class="btn btn-primary" data-bs-target="#registration_popup" data-bs-toggle="modal">Create</button>
            </div>
        </div>
    </div>
</div>
<!-- login popup end -->

<!-- registration popup -->
<div class="ja_modal modal fade" id="registration_popup" aria-hidden="true" aria-labelledby="exregistration_popup" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exregistration_popup">Registration</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
	    <?php echo do_shortcode('[woocommerce_custom_registration]') ?>
      </div>
	  <div class="modal-footer">
		Already have an account
        <button class="btn btn-primary" data-bs-target="#loginModal" data-bs-toggle="modal">login</button>
      </div>    
	</div>
  </div>
</div>
<!-- registration popup end -->

<!-- forgot pass popup popup -->
<!-- <div class="modal fade" id="forgot_pass_popup" aria-hidden="true" aria-labelledby="exforgot_pass_popup" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exforgot_pass_popup">Forgot your password?</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo do_shortcode('[woocommerce_reset_password]') ?>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" data-bs-target="#loginModal" data-bs-toggle="modal">login</button>
      </div>
    </div>
  </div>
</div> -->
<!-- forgot pass popup popup end -->

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'nanaobiriyeboah' ); ?></a>
	
	<?php get_template_part( 'template-parts/header/nav/sub',  'header'); ?>
	<header id="masthead" class="site-header sticky_nav">
	    <?php get_template_part( 'template-parts/header/nav/content',  'nav'); ?>
		
	</header><!-- #masthead -->

