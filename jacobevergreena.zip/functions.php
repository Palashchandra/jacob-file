<?php
/**
 * nanaobiriyeboah functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package nanaobiriyeboah
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! defined( 'nanaobiriyeboah_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( 'nanaobiriyeboah_VERSION', wp_get_theme()->get( 'Version' ) );
}

if ( ! defined( 'nanaobiriyeboah_THEMEROOT' ) ) {
	// Replace the version number of the theme on each release.
	define( 'nanaobiriyeboah_THEMEROOT', get_template_directory_uri());
}

if ( ! defined( 'nanaobiriyeboah_THEMEROOT_DIR' ) ) {
	// Replace the version number of the theme on each release.
	define( 'nanaobiriyeboah_THEMEROOT_DIR', get_template_directory());
}

if ( ! defined( 'nanaobiriyeboah_IMAGES' ) ) {
	// Replace the version number of the theme on each release.
	define( 'nanaobiriyeboah_IMAGES', nanaobiriyeboah_THEMEROOT.'/assets/images');
}

if ( ! defined( 'nanaobiriyeboah_CSS' ) ) {
	// Replace the version number of the theme on each release.
	define( 'nanaobiriyeboah_CSS', nanaobiriyeboah_THEMEROOT.'/assets/css');
}

if ( ! defined( 'nanaobiriyeboah_JS' ) ) {
	// Replace the version number of the theme on each release.
	define( 'nanaobiriyeboah_JS', nanaobiriyeboah_THEMEROOT.'/assets/js');
}


if ( ! defined( 'nanaobiriyeboah_vendor_CSS' ) ) {
	// Replace the version number of the theme on each release.
	define( 'nanaobiriyeboah_vendor_CSS', nanaobiriyeboah_THEMEROOT.'/assets/vendors');
}
if ( ! defined( 'nanaobiriyeboah_vendor_JS' ) ) {
	// Replace the version number of the theme on each release.
	define( 'nanaobiriyeboah_vendor_JS', nanaobiriyeboah_THEMEROOT.'/assets/vendors');
}


if ( ! function_exists( 'nanaobiriyeboah_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function nanaobiriyeboah_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on nanaobiriyeboah, use a find and replace
		 * to change 'nanaobiriyeboah' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'nanaobiriyeboah', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary', 'nanaobiriyeboah' ),
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'nanaobiriyeboah_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);

		add_theme_support('woocommerce');

	}
endif;
add_action( 'after_setup_theme', 'nanaobiriyeboah_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function nanaobiriyeboah_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'nanaobiriyeboah_content_width', 640 );
}
add_action( 'after_setup_theme', 'nanaobiriyeboah_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function nanaobiriyeboah_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'nanaobiriyeboah' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'nanaobiriyeboah' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar( array(
		'name' => esc_html__( 'Shop Sidebar', 'machic' ),
		'id' => 'shop-sidebar',
		'description'   => esc_html__( 'These are widgets for the Shop.','machic' ),
		'before_widget' => '<div class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>'
	) );
}
add_action( 'widgets_init', 'nanaobiriyeboah_widgets_init' );

/**
 * nanaobiriyeboah required function init  
 */
require_once nanaobiriyeboah_THEMEROOT_DIR . '/inc/init.php'; 

/**
 *  nanaobiriyeboah options and metabox init 
 */

require_once nanaobiriyeboah_THEMEROOT_DIR . '/lib/init.php';

function custom_woocommerce_archive_posts_per_page( $query ) {
    if ( is_shop() || is_product_category() || is_product_tag() ) {
        $query->set( 'posts_per_page', 8 ); // Adjust number of products per page
    }
}
add_action( 'pre_get_posts', 'custom_woocommerce_archive_posts_per_page' );


function woocommerce_reset_password_shortcode() {
    ob_start();
    if ( is_user_logged_in() ) {
        return __('You are already logged in.', 'woocommerce');
    } else {
        wc_get_template( 'myaccount/form-reset-password.php' );
    }
    return ob_get_clean();
}
add_shortcode( 'woocommerce_reset_password', 'woocommerce_reset_password_shortcode' );

function woocommerce_login_form_shortcode() {
    ob_start();
    if ( is_user_logged_in() ) {
        return __('You are already logged in.', 'woocommerce');
    } else {
        wc_get_template( 'myaccount/form-login.php' );
    }
    return ob_get_clean();
}
add_shortcode( 'woocommerce_login', 'woocommerce_login_form_shortcode' );


function woocommerce_registration_form_shortcode() {
    if ( is_user_logged_in() ) {
        return __('You are already logged in.', 'woocommerce');
    }

    ob_start();
    ?>
    <h2><?php _e( 'Register', 'woocommerce' ); ?></h2>
    <form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?> >

        <?php do_action( 'woocommerce_register_form_start' ); ?>

        <?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>

            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" />
            </p>

        <?php endif; ?>

        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
            <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" />
        </p>

        <?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>

            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="reg_password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" />
            </p>

        <?php else : ?>

            <p><?php esc_html_e( 'A password will be sent to your email address.', 'woocommerce' ); ?></p>

        <?php endif; ?>

        <?php do_action( 'woocommerce_register_form' ); ?>

        <p class="woocommerce-form-row form-row">
            <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
            <button type="submit" class="woocommerce-Button button" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce' ); ?>"><?php esc_html_e( 'Register', 'woocommerce' ); ?></button>
        </p>

        <?php do_action( 'woocommerce_register_form_end' ); ?>

    </form>
    <?php

    return ob_get_clean();
}
add_shortcode( 'woocommerce_custom_registration', 'woocommerce_registration_form_shortcode' );
