<?php 

/**
  * Display page banner 
  */

?>

<div class="blog_breadcrumbs_area_two">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="breadcrumb_content text-white text-center">
                    <h2 class="page_title">Search All Courses</h2>
                    <p class="description">Explore Over 10,000 Courses: Online, Classroom, and Self-Paced. Each course is designed with excellence in mind.</p>
                    <div class="mt-4">
                        <?php echo nanaobiriyeboah_product_search() ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>