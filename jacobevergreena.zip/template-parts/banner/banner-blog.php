<?php 

/**
  * Display page banner 
  */
  $show_banner = nanaobiriyeboah_options('nanaobiriyeboah_blog_banner_toggle', 'show');
  
  $banner_url = nanaobiriyeboah_options('nanaobiriyeboah_blog_banner_upload');
  
  $how_title = nanaobiriyeboah_options('nanaobiriyeboah_blog_banner_title', 'show');
  $title = nanaobiriyeboah_options('nanaobiriyeboah_blog_title', get_bloginfo('name'));
  $description = nanaobiriyeboah_options('nanaobiriyeboah_blog_description');
?>

<div class="blog_breadcrumbs_area_two parallaxie">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="breadcrumb_content text-white text-center">
                    <?php if($how_title == 'show') : ?>
                        <h2 class="page_title"><?php echo esc_html( $title ); ?></h2>
                    <?php endif; ?> 
                    <p class="description"><?php echo $description; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>