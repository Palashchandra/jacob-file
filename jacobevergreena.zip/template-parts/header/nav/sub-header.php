<?php
    $offer_text = nanaobiriyeboah_options('h_top_txt');
	$btn_icon = nanaobiriyeboah_options('icon_select_field');
    $offer_btn_text = nanaobiriyeboah_options('support_btn_text');
    $offer_btn_link = nanaobiriyeboah_options('support_btn_link');
?>
<?php if(class_exists('Redux')) : ?>
    <div class="sub_header header-top-bar-area">
        <div class="container custom_container">
            <div class="row">
                <div class="col-md-2 col-6">
                    <div class="sub_header_left">
							<a href="<?php echo $offer_btn_link;?>"><i class="<?php echo $btn_icon; ?>"></i><?php echo $offer_btn_text;?></a>
                    </div>
                </div>
                <div class="col-md-8 d-none d-md-block">
                    <div class="sub_header_middle text-center">
                        <p><?php echo $offer_text; ?></p>
                    </div>
                </div>
                <div class="col-md-2 col-6">
                    <div class="sub_header_right">
                        <?php echo do_shortcode('[gtranslate]'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>