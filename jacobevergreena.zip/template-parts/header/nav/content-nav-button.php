<?php
$user_btn_text = nanaobiriyeboah_options('user_btn_text');
$user_btn_link = nanaobiriyeboah_options('user_btn_link');
// Get the current logged-in user object
$current_user = wp_get_current_user();  
// Get the user_nicename
$user_nicename = esc_html( $current_user->display_name );
// Get the user's Gravatar image with a size of 96px (you can adjust the size as needed)
$user_avatar = get_avatar( $current_user->ID, 96 );
// Get the URL of the "My Account" page
$my_account_url = wc_get_page_permalink( 'myaccount' );
?>
<div class="nav_meta">
    <div class="nav_meta_item">
		<ul class="navbar-nav search_meta">
			<li class="nav-item menu_search">
				<div class="search-btn">
					<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
						<circle cx="13.5028" cy="13.5247" r="10.1121" stroke="#D8D8D8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M20.5352 21.083L24.4997 25.0372" stroke="#D8D8D8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
                </div>
			</li>
			<li class="nav-item shopping_cart">
				<a href="#" class="cart-btn">
					<svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path fill-rule="evenodd" clip-rule="evenodd" d="M16.3122 6.16211C16.348 6.08238 16.3648 5.99548 16.3612 5.90822H16.3906C16.2648 2.90626 13.7861 0.537109 10.7712 0.537109C7.75624 0.537109 5.27756 2.90626 5.15175 5.90822C5.13692 5.99221 5.13692 6.07813 5.15175 6.16211H5.0638C3.62212 6.16211 2.08101 7.11382 1.63359 9.67219L0.758643 16.6412C0.0427733 21.7579 2.67757 23.0371 6.11772 23.0371H15.4439C18.8741 23.0371 21.4294 21.1849 20.793 16.6412L19.928 9.67219C19.4011 7.18546 17.9097 6.16211 16.4879 6.16211H16.3122ZM14.6955 6.16211C14.6642 6.08105 14.6476 5.99508 14.6465 5.90822C14.6465 3.75104 12.8917 2.00229 10.7271 2.00229C8.56247 2.00229 6.80769 3.75104 6.80769 5.90822C6.82253 5.99221 6.82253 6.07813 6.80769 6.16211H14.6955ZM7.49975 11.9543C6.95063 11.9543 6.50548 11.4961 6.50548 10.9309C6.50548 10.3657 6.95063 9.90756 7.49975 9.90756C8.04886 9.90756 8.49401 10.3657 8.49401 10.9309C8.49401 11.4961 8.04886 11.9543 7.49975 11.9543ZM13.0179 10.9309C13.0179 11.4961 13.4631 11.9543 14.0122 11.9543C14.5613 11.9543 15.0064 11.4961 15.0064 10.9309C15.0064 10.3657 14.5613 9.90756 14.0122 9.90756C13.4631 9.90756 13.0179 10.3657 13.0179 10.9309Z" fill="#D8D8D8"/>
					<circle cx="15.5" cy="5.51437" r="6.22726" fill="#FACE0D"/>
					</svg>
				</a>
				<div class="cart_dropdown_inner">
					<div class="cart_header d-flex justify-content-between">
						Cart (02) 
						<span class="close"><i class="fas fa-times"></i></span>
					</div>
					<div class="cart_item">
						<div class="cart_title">
							Artificial Intelligence and Machine Learning
						</div>
						<div class="cart_delete">
							<i class="fas fa-trash-alt"></i>
						</div>
						<h6>
							This course includes:
						</h6>
						<ul class="list-unstyled course_list">
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">4 hours on-demand video</li>
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">10 article</li>
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">5 downloadable resources</li>
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">8:30 AM - 4:30 PM EDT</li>
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">Location: Online</li>
						</ul>
						<div class="price text-end">
							$599.00
						</div>
					</div>
					<div class="cart_item">
						<div class="cart_title">
							Artificial Intelligence and Machine Learning
						</div>
						<div class="cart_delete">
							<i class="fas fa-trash-alt"></i>
						</div>
						<h6>
							This course includes:
						</h6>
						<ul class="list-unstyled course_list">
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">4 hours on-demand video</li>
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">10 article</li>
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">5 downloadable resources</li>
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">8:30 AM - 4:30 PM EDT</li>
							<li><img src="https://oyolloo.online/jacobevergreena/wp-content/uploads/2024/04/check-svg.svg" alt="check">Location: Online</li>
						</ul>
						<div class="price text-end">
							$599.00
						</div>
					</div>
					<div class="cart_footer d-flex justify-content-between">
						Total
						<div class="t_price">
							$899.00
						</div>
					</div>
					<button class="btn btn-cart">Proceed to Checkout <i class="fas fa-arrow-right"></i></button>
				</div>
			</li>
			<li>
				<?php if(is_user_logged_in()) : ?>
					<div class="login_user">
						<?php 
							// Display the user_nicename and Gravatar image as a link to the "My Account" page
							echo '<a class="user-profile" href="' . esc_url( $my_account_url ) . '">';
							echo $user_avatar;
							echo '<p>' . $user_nicename . '</p>';
							echo '</a>';
						?>
					</div>
				<?php else : ?>
					<button type="button" class="cu_btn btn_1" data-bs-toggle="modal" data-bs-target="#loginModal">
						<?php echo $user_btn_text ?> 
						<svg width="21" height="17" viewBox="0 0 21 17" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M19.3066 8.46708L1.80664 8.46708" stroke="#111111" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M12.248 1.43862L19.3064 8.46662L12.248 15.4958" stroke="#111111" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
					</button>
				<?php endif; ?>
			</li>
		</ul>
        <!-- <a class="cu_btn btn_1" href="<?php echo $user_btn_link; ?>">
            <?php echo $user_btn_text ?> 
            <svg width="21" height="17" viewBox="0 0 21 17" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19.3066 8.46708L1.80664 8.46708" stroke="#111111" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12.248 1.43862L19.3064 8.46662L12.248 15.4958" stroke="#111111" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </a> -->
		
    </div>
</div>