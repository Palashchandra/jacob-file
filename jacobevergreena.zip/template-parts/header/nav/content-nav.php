<nav class="navbar navbar-expand-xl menu_one p-0">
    <div class="container custom_container position-relative">
        <div class="header_part_wrapper d-flex align-items-center justify-content-between">
            <div class="navbar_logo">
                <?php nanaobiriyeboah_logo(); ?>
            </div>
            
            <div class="header_menu_inner collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                <?php 
                    wp_nav_menu( array(
                        'menu_class' => 'navbar-nav menu',
                        'container'  => '',
                        'theme_location' => 'primary',
                        'walker'         => new nanaobiriyeboah_Navwalker(),
                        'fallback_cb'     => false,
                    ) ); 
                ?>
            </div>
            <div class="header_left_content d-flex align-items-center justify-content-between">
                <div class="header_right_content">
                    <?php get_template_part( 'template-parts/header/nav/content-nav', 'button'); ?>
                </div>
            </div>
        </div>
        <div class="search_box position-absolute start-0 w-100" style="display: none;">
			<?php echo nanaobiriyeboah_product_search() ?>
		</div>
    </div>
    <div class="search_box_overlay"></div>
</nav>