<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nanaobiriyeboah
 */

?>

<div class="blog_post_item">
	<?php if(!empty(get_the_post_thumbnail_url())) : ?>
		<a href="<?php echo get_the_permalink(); ?>" class="post_thumb">
			<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#" class="img-fluid">
		</a>
	<?php endif; ?>
	
	<div class="post_content">
		<div class="post_meta">
			<?php 
				$categories = get_the_category();
				if ($categories) {
					// Get the first category from the array
					$first_category = $categories[0];
					
					// Output the first category name with the static "5 min read" span tag
					echo '<p>' . esc_html($first_category->name) . ' <span>5 min read</span></p>';
				}
			?>
			<p class="post-date">
				<?php echo get_the_date('j M, Y'); ?>
			</p>
		</div>
		<h5 class="title"><a href="<?php echo get_the_permalink(); ?>"><?php echo the_title(); ?></a></h5>
		<p class="description"><?php echo wp_trim_words(get_the_excerpt(), 10, '....') ; ?></p>
		<a href="<?php echo get_the_permalink(); ?>" class="read_more">Read More <i class="fas fa-arrow-right"></i></a>
	</div>
</div>
