<?php 
/**
 * template to display single page content 
 */

?>
<div class="blog_single_info">
    <div class="media_blog_content">
        <?php  if(has_post_thumbnail( )) {  ?>
        <div class="single-page-media">
           <?php the_post_thumbnail(); ?>
        </div>
        <?php } ?>
       
        <?php the_content();
        ?>
    </div>
</div>
                      
    <!-- End medical blog list area -->

 