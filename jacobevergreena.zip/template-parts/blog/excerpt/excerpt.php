<?php
/**
 * Show the excerpt.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage nanaobiriyeboah
 * @since nanaobiriyeboah 1.0
 */

the_excerpt();
