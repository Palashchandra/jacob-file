jQuery(function () {
	'use strict';
	//*============ background image js ==============*/

	$('[data-bg-img]').each(function () {
		var bg = $(this).data('bg-img');
		$(this).css({
			background: 'no-repeat center 0/cover url(' + bg + ')',
		});
	});

	//* Navbar Fixed
	// function navbarFixed() {
	// 	if ($('.sticky_nav').length) {
	// 		$(window).scroll(function () {
	// 			var scroll = $(window).scrollTop();
	// 			if (scroll) {
	// 				$('.sticky_nav').addClass('navbar_fixed');
	// 			} else {
	// 				$('.sticky_nav').removeClass('navbar_fixed');
	// 			}
	// 		});
	// 	}
	// }

	// navbarFixed();

	$(".navbar-toggler").on("click", function(){
		$(".navbar.fixed-top").toggleClass("menu_collaps");
	});
	$(".accordion-item").on("click", function(){
		$(".accordion-item").removeClass("accordion-item-active");
		$(this).toggleClass("accordion-item-active");
	});

	// dropdown-toggle 
    $('.dropdown-menu > .dropdown > a').addClass('dropdown-toggle');
    $('.dropdown-menu a.dropdown-toggle').on('click', function (e) {
        if (!$(this).next().hasClass('show')) {
            $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
        }
        var $subMenu = $(this).next(".dropdown-menu");
        $subMenu.toggleClass('show');
        $(this).parents('li.nav-item.dropdown.show').on('.dropdown', function (e) {
            $('.dropdown-menu > .dropdown .show').removeClass("show");
        });
        return false;
    });

	
	function cartActivator() {
        if ($(".cart-btn").length) {
            $(".cart-btn").on("click", function () {
                $(".shopping_cart").toggleClass("show-menu");
            });
            $(".close").on("click", function () {
                $(".shopping_cart").removeClass("show-menu");
            });
        }
    }
    cartActivator();
	
	//swiper slider
	

    //card slider js
    // var swiper = new Swiper(".cre_portfolio_slider", {
    //     slidesPerView: 2,
    //     loop: true,
    //     autoplay: true,
    //     grid: {
    //         rows: 2,
    //         fill: 'row',
    //     },
    //     spaceBetween: 30,
    //     navigation: {
    //         nextEl: ".swiper-portfolio-next",
    //         prevEl: ".swiper-portfolio-prev",
    //     },
    // });

    //card slider js
    // var swiper = new Swiper(".cre_testimonial_slider", {
    //     slidesPerView: 3,
    //     loop: true,
    //     spaceBetween: 100,
    //     centeredSlides: true,
    //     autoplay: true,
    //     navigation: {
    //         nextEl: ".swiper-testimonial-next",
    //         prevEl: ".swiper-testimonial-prev",
    //     },
    //     breakpoints: {
    //         // when window width is >= 320px
    //         320: {
    //           slidesPerView: 1,
    //           spaceBetween: 50
    //         },
    //         // when window width is >= 480px
    //         576: {
    //           slidesPerView: 1,
    //           spaceBetween: 50
    //         },
    //         // when window width is >= 640px
    //         768: {
    //           slidesPerView: 2,
    //           spaceBetween: 60
    //         },
    //         1024: {
    //             slidesPerView: 3,
    //             spaceBetween: 70
    //         },
    //         1200: {
    //             slidesPerView: 3,
    //             spaceBetween: 100
    //         }
    //       }
    // });

    //card slider js
    var swiper = new Swiper(".banner_logo_slider", {
        slidesPerView: 7,
        loop: true,
        spaceBetween: 70,
        autoplay: true,
        breakpoints: {
            // when window width is >= 320px
            320: {
              slidesPerView: 3,
              spaceBetween: 20,
              centeredSlides: true,
            },
            // when window width is >= 480px
            576: {
              slidesPerView: 4,
              spaceBetween: 30,
              centeredSlides: true,
            },
            // when window width is >= 640px
            768: {
              slidesPerView: 4,
              spaceBetween: 60,
              centeredSlides: true,
            },
            1024: {
                slidesPerView: 5,
                spaceBetween: 60,
                centeredSlides: false,
            },
            1200: {
                slidesPerView: 7,
                spaceBetween: 70
            }
          }
    });


    $('.poppup_button').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
	});


    $(document).ready(function() {
        // Open popup when the button is clicked
        $('#apply_popupButton').click(function() {
            $('.apply_popup').fadeIn();
        });
    
        // Close popup when the close button (×) is clicked
        $('.apply_close').click(function() {
            $('.apply_popup').fadeOut();
        });
    
        // Close popup when clicking outside of the popup content
        $(window).click(function(event) {
            if (event.target === $('.apply_popup')[0]) {
                $('.apply_popup').fadeOut();
            }
        });
    });

    //cookis js
    function setCookie(name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }

    function acceptCookies() {
        setCookie('cookiesAccepted', '1', 30);
        hidePopup();
    }

    function declineCookies() {
        setCookie('cookiesAccepted', '0', 30);
        hidePopup();
    }

    $('.c_accept_btn').on('click', function(){
        acceptCookies();
    })
    
    $('.c_decline_btn').on('click', function(){
        declineCookies();
    })

    function hidePopup() {
        document.getElementById('cookiePopup').style.display = 'none';
        document.getElementById('overlay').style.display = 'none';
        enableScroll(); // Re-enable scroll
    }

    function showPopup() {
        document.getElementById('cookiePopup').style.display = 'block';
        document.getElementById('overlay').style.display = 'block';
        disableScroll(); // Disable scroll
    }

    function checkCookieConsent() {
        var cookiesAccepted = getCookie('cookiesAccepted');
        if (cookiesAccepted === '1' || cookiesAccepted === '') {
            // Hide the popup if cookies have been accepted or no preference is set
            hidePopup();
        } else {
            // Show the popup if cookies have been declined
            showPopup();
        }
    }

    function getCookie(name) {
        var nameEQ = name + "=";
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i];
            while (cookie.charAt(0) === ' ') {
                cookie = cookie.substring(1, cookie.length);
            }
            if (cookie.indexOf(nameEQ) === 0) {
                return cookie.substring(nameEQ.length, cookie.length);
            }
        }
        return null;
    }

    function disableScroll() {
        document.body.addEventListener('mousewheel', preventDefault, { passive: false }); // Modern browsers
        document.body.addEventListener('DOMMouseScroll', preventDefault, { passive: false }); // Older Firefox
    }

    function enableScroll() {
        document.body.removeEventListener('mousewheel', preventDefault, { passive: false });
        document.body.removeEventListener('DOMMouseScroll', preventDefault, { passive: false });
    }

    function preventDefault(event) {
        event.preventDefault();
    }

    window.onload = checkCookieConsent;


    function filter_dropdown_two() {
        if ($(window).width() < 992 ) {
            $(".all_course_sidebar .filter_btn").on("click", function (event) {
            $(this).parent().find(".co_filter_inner").first().toggle(700);
            $(this).toggleClass("active");
            });
        }
    }
    filter_dropdown_two();

    //dropdown title js
    $('.dropdown_title').click(function() {
        $(this).toggleClass('addAnchor')
        $(this).siblings('.dropdown_content').slideToggle();
    });

    //course fee show js
    $('.ch_price').hide();
    $('.course_price').on('click', function (e) {
        e.preventDefault();
        $(this).children('.ch_btn_text').hide();
        $(this).children('.ch_price').show();
    });
    
    $('.search_box').hide();
    $('.search-btn').on('click', function (e) {
        $('.search_box').show();
        $('.overlay').show();
    });
    $('.overlay').on('click', function (e) {
        $(this).hide();
        $('.search_box').hide();
    });
});

