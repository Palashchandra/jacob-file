<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package nanaobiriyeboah
 */
$footer_text = nanaobiriyeboah_options('nanaobiriyeboah_copyright_txt', 'Copyright &copy; 2023 <a href="#">oyolloo</a> | All rights reserved');

?>

	<footer class="site-footer">
		
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
