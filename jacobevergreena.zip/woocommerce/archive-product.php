<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.0
 */
defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="primary" class="site-main">
    <?php get_template_part('template-parts/banner/banner', 'search'); ?>
    <div class="blog_section search_page_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="all_course_sidebar">
						<div class="filter_btn">
							<h4 class="title"> 
                                Filters 
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="33" viewBox="0 0 32 33" fill="none"><path d="M1 6.62361H16.2253C16.6842 8.71229 18.5494 10.2804 20.7739 10.2804C22.9984 10.2804 24.8637 8.71236 25.3226 6.62361H31C31.5522 6.62361 32 6.17586 32 5.62361C32 5.07136 31.5522 4.62361 31 4.62361H25.3221C24.8623 2.53598 22.9945 0.966919 20.7739 0.966919C18.5522 0.966919 16.6852 2.53573 16.2257 4.62361H1C0.44775 4.62361 0 5.07136 0 5.62361C0 6.17586 0.44775 6.62361 1 6.62361ZM18.1173 5.62623C18.1173 5.62267 18.1174 5.61904 18.1174 5.61548C18.1217 4.15504 19.3134 2.96698 20.7739 2.96698C22.2324 2.96698 23.4241 4.15342 23.4304 5.61317L23.4306 5.62786C23.4283 7.09079 22.2374 8.28042 20.7739 8.28042C19.3111 8.28042 18.1206 7.09198 18.1173 5.62992L18.1173 5.62623ZM31 27.3412H25.3221C24.8623 25.2536 22.9945 23.6845 20.7739 23.6845C18.5522 23.6845 16.6852 25.2534 16.2257 27.3412H1C0.44775 27.3412 0 27.7889 0 28.3412C0 28.8935 0.44775 29.3412 1 29.3412H16.2253C16.6842 31.4299 18.5494 32.9979 20.7739 32.9979C22.9984 32.9979 24.8637 31.4299 25.3226 29.3412H31C31.5522 29.3412 32 28.8935 32 28.3412C32 27.7889 31.5522 27.3412 31 27.3412ZM20.7739 30.9979C19.3111 30.9979 18.1206 29.8095 18.1173 28.3474L18.1173 28.3438C18.1173 28.3402 18.1174 28.3366 18.1174 28.333C18.1217 26.8726 19.3134 25.6845 20.7739 25.6845C22.2324 25.6845 23.4241 26.8709 23.4304 28.3306L23.4306 28.3453C23.4285 29.8084 22.2376 30.9979 20.7739 30.9979ZM31 15.9824H15.7747C15.3158 13.8937 13.4506 12.3257 11.2261 12.3257C9.00156 12.3257 7.13631 13.8937 6.67744 15.9824H1C0.44775 15.9824 0 16.4302 0 16.9824C0 17.5347 0.44775 17.9824 1 17.9824H6.67794C7.13775 20.07 9.0055 21.6391 11.2261 21.6391C13.4478 21.6391 15.3148 20.0702 15.7743 17.9824H31C31.5522 17.9824 32 17.5347 32 16.9824C32 16.4302 31.5522 15.9824 31 15.9824ZM13.8827 16.9798C13.8827 16.9834 13.8826 16.987 13.8826 16.9905C13.8782 18.451 12.6866 19.639 11.2261 19.639C9.76763 19.639 8.57588 18.4526 8.56956 16.9929L8.56938 16.9783C8.57156 15.5152 9.7625 14.3257 11.2261 14.3257C12.6889 14.3257 13.8794 15.5141 13.8827 16.9762L13.8827 16.9798Z" fill="white"></path></svg>
                            </h4>
							<p>Current selected course: 152 </p>
						</div>
						<?php echo do_shortcode('[yith_wcan_filters slug="default-preset"]') ?>
					</div>   
                </div>
                <div class="col-md-8">
				<div class="cre_course_item_inner">
						<?php

						if ( have_posts() ) {
							while ( have_posts() ) {
								the_post();
								global $product;
								?>
								<div class="cre_course_items">
									<h5 class="title"><?php the_title(); ?></h5>
									<div class="course_details_content">
										<ul class="cre_course_details">
											<li><span>Duration:</span> 5 Days</li>
											<li><span>Exam:</span> AZ-800</li>
											<li><span>Language:</span> English</li>
											<li><span>Level:</span> Fundamental</li>
										</ul>
										<div class="add-to-cart">
											<?php 
											$args = array(
												'quantity' => 1,
												'class'    => implode( ' ', array_filter( array(
													'course_add_cart',
													'product_type_' . $product->get_type(),
													$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
													$product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
												) ) ),
											);

											woocommerce_template_loop_add_to_cart( $args );
											?>
										</div>
										<div class="d-flex course_meta">
											<a href="#" class="course_details_btn course_price" data-product-id="<?php echo get_the_ID(); ?>">
												<span class="ch_btn_text">See Price <i class="fas fa-arrow-right"></i></span>
												<span class="ch_price">
													<?php
													if ( $product ) {
														$display_price = $product->get_price();
														echo 'Price: ' . wc_price( $display_price );
													}
													?>
												</span>
											</a>
											<a href="<?php the_permalink(); ?>" class="course_details_btn">Dates & Details<i class="fas fa-arrow-right"></i></a>
										</div>
									</div>
								</div>
								<?php
							}
							// Pagination
							echo '<div class="pagination">';
							echo paginate_links( apply_filters( 'woocommerce_pagination_args', array(
								'prev_text' => '<i class="fas fa-chevron-left"></i>',
                                'next_text' => '<i class="fas fa-chevron-right"></i>',
							) ) );
							echo '</div>';

							wp_reset_postdata(); // Reset post data
						} else {
							// No posts found
							echo 'No courses found.';
						}
						?>
					</div>

                </div>
            </div>
        </div>
    </div>
</main><!-- #main -->

<?php

get_footer();
