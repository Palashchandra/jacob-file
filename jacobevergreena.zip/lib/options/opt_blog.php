<?php

Redux::set_section('nanaobiriyeboah', array(
	'title'     => esc_html__( 'Blog', 'nanaobiriyeboah' ),
	'id'        => 'blog_page',
	'icon'      => 'dashicons dashicons-admin-post',
));



