<?php
    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Cookies Popup', 'nanaobiriyeboah' ),
        'id'                => 'cookies_popup',
        'customizer_width'  => '400px',
        'icon'              => 'el el-home'
    ));

    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Header Content', 'nanaobiriyeboah' ),
        'id'                => 'cookies_popup_content',
        'subsection'        => true,
        'fields'            => array(
            array(
                'id' => 'popup_title',
                'type' => 'text',
                'title' => __( 'Popup Title' , 'nanaobiriyeboah' ),
                'default'   => __( 'Cookies Settings', 'nanaobiriyeboah' ),
            ),
            array(
				'title'     => esc_html__('Popup Description', 'nanaobiriyeboah'),
				'id'        => 'popup_description',
				'type'      => 'editor',
				'default'   => 'Buy More, Save More with our exclusive Instructor Led Training Prepay Packages!',
				'args'    => array(
					'wpautop'       => true,
					'media_buttons' => false,
					'textarea_rows' => 10,
					'teeny'         => false,
				)
			),
            array(
                'id' => 'list_title',
                'type' => 'text',
                'title' => __( 'List Title' , 'nanaobiriyeboah' ),
                'default'   => __( 'Functionality Allowed', 'nanaobiriyeboah' ),
            ),
            
            array(
				'title'     => esc_html__('Popup functionality', 'nanaobiriyeboah'),
				'id'        => 'popup_functionality',
				'type'      => 'editor',
				'default'   => 'Buy More, Save More with our exclusive Instructor Led Training Prepay Packages!',
				'args'    => array(
					'wpautop'       => true,
					'media_buttons' => false,
					'textarea_rows' => 10,
					'teeny'         => false,
				)
			),

            array(
				'id'=>'icon_select_field',
				'type' => 'icon_select', 
				//'required' => array('switch-fold','equals','0'),	
				'title' => __('Icon Select', 'nanaobiriyeboah'),
				'subtitle'	=> __('Select an icon.', 'nanaobiriyeboah'),
				'default' 	=> 'fa-brands fa-facebook-f',
			),
        )
    ));
?>