<?php
    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Header Top', 'nanaobiriyeboah' ),
        'id'                => 'sub_header',
        'customizer_width'  => '400px',
        'icon'              => 'el el-home'
    ));

    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Header Content', 'nanaobiriyeboah' ),
        'id'                => 'sub_header_meta',
        'subsection'        => true,
        'fields'            => array(
			array(
				'title'     => esc_html__('Header Top Text', 'nanaobiriyeboah'),
				'id'        => 'h_top_txt',
				'type'      => 'editor',
				'default'   => 'Buy More, Save More with our exclusive Instructor Led Training Prepay Packages!',
				'args'    => array(
					'wpautop'       => true,
					'media_buttons' => false,
					'textarea_rows' => 10,
					'teeny'         => false,
				)
			),
            array(
                'id' => 'support_btn_text',
                'type' => 'text',
                'title' => __( 'Header Button Text' , 'nanaobiriyeboah' ),
                'default'   => __( 'Support', 'nanaobiriyeboah' ),
            ),
            array(
                'id' => 'support_btn_link',
                'type' => 'text',
                'title' => __( 'Header Button Link' , 'nanaobiriyeboah' ),
                'default'   => __( '#', 'nanaobiriyeboah' ),
            ),
			array(
				'id'=>'icon_select_field',
				'type' => 'icon_select', 
				//'required' => array('switch-fold','equals','0'),	
				'title' => __('Icon Select', 'nanaobiriyeboah'),
				'subtitle'	=> __('Select an icon.', 'nanaobiriyeboah'),
				'default' 	=> 'fa-brands fa-facebook-f',
			),
        )
    ));
?>