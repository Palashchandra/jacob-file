<?php
// Header Section
Redux::set_section( 'nanaobiriyeboah', array(
    'title'            => esc_html__( 'Header', 'nanaobiriyeboah' ),
    'id'               => 'nanaobiriyeboah_header_sec',
    'customizer_width' => '400px',
    'icon'             => 'el el-arrow-up',
));


// Logo
Redux::set_section( 'nanaobiriyeboah', array(
    'title'            => esc_html__( 'Logo', 'nanaobiriyeboah' ),
    'id'               => 'nanaobiriyeboah_logo_opt',
    'subsection'       => true,
    'icon'             => '',
    'fields'           => array(
        array(
            'title'     => esc_html__( 'Upload logo', 'nanaobiriyeboah' ),
            'subtitle'  => esc_html__( 'Upload here a image file for your logo', 'nanaobiriyeboah' ),
            'id'        => 'nanaobiriyeboah_logo',
            'type'      => 'media',
            'default'   => array(
                'url'   => nanaobiriyeboah_IMAGES.'/default_logo/logo.png'
            )
        ),

        array(
            'title'     => esc_html__( 'Sticky header logo', 'nanaobiriyeboah' ),
            'id'        => 'nanaobiriyeboah_sticky_logo',
            'type'      => 'media',
            'default'   => array(
                'url'   => nanaobiriyeboah_IMAGES.'/default_logo/logo_sticky.png'
            )
        ),

        array(
            'title'     => esc_html__( 'Retina Logo', 'nanaobiriyeboah' ),
            'subtitle'  => esc_html__( 'The retina logo should be double (2x) of your original logo', 'nanaobiriyeboah' ),
            'id'        => 'nanaobiriyeboah_retina_logo',
            'type'      => 'media',
        ),

        array(
            'title'     => esc_html__( 'Retina Sticky Logo', 'nanaobiriyeboah' ),
            'subtitle'  => esc_html__( 'The retina logo should be double (2x) of your original logo', 'nanaobiriyeboah' ),
            'id'        => 'nanaobiriyeboah_retina_sticky_logo',
            'type'      => 'media',
        ),

        array(
            'title'     => esc_html__( 'Logo dimensions', 'nanaobiriyeboah' ),
            'subtitle'  => esc_html__( 'Set a custom height width for your upload logo.', 'nanaobiriyeboah' ),
            'id'        => 'logo_dimensions',
            'type'      => 'dimensions',
            'units'     => array( 'em','px','%' ),
            'output'    => '.logo_info .navbar-brand img'
        ),

        array(
            'title'     => esc_html__( 'Padding', 'nanaobiriyeboah' ),
            'subtitle'  => esc_html__( 'Padding around the logo. Input the padding as clockwise (Top Right Bottom Left)', 'nanaobiriyeboah' ),
            'id'        => 'logo_padding',
            'type'      => 'spacing',
            'output'    => array( '.logo_info .navbar-brand img' ),
            'mode'      => 'padding',
            'units'     => array( 'em', 'px', '%' ),      // You can specify a unit value. Possible: px, em, %
            'units_extended' => 'true',
        ),
        
    )
) );

Redux::setSection( $opt_name, array(
	'title'             => esc_html__( 'Header Button', 'nanaobiriyeboah' ),
	'id'                => 'header_meta',
	'subsection'        => true,
	'fields'            => array(
		array(
			'id' => 'user_btn_text',
			'type' => 'text',
			'title' => __( 'Header Button Text' , 'nanaobiriyeboah' ),
			'default'   => __( 'Sign In', 'nanaobiriyeboah' ),
		),
		array(
			'id' => 'user_btn_link',
			'type' => 'text',
			'title' => __( 'Header Button Link' , 'nanaobiriyeboah' ),
			'default'   => __( '#', 'nanaobiriyeboah' ),
		),
	)
));