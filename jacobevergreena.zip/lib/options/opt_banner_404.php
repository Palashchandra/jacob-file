<?php 
Redux::set_section('nanaobiriyeboah', array(
    'title'            => esc_html__( '404 Banner', 'nanaobiriyeboah' ),
    'id'               => 'nanaobiriyeboah_404_banner',
    'icon'             => 'el el-cog',
    'subsection' => true,
    'fields'           => array(
        array(
            'id'       => 'nanaobiriyeboah_404_banner_toggle',
            'type'     => 'button_set',
            'title'    => esc_html__('Show 404  Banner', 'nanaobiriyeboah'),
            'options' => array(
                'show' => esc_html__('Show Banner', 'nanaobiriyeboah'), 
                'hide' => esc_html__('Hide Banner', 'nanaobiriyeboah'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'nanaobiriyeboah_404_title',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Title', 'nanaobiriyeboah'),
            'options' => array(
                'show' => esc_html__('Show', 'nanaobiriyeboah'), 
                'hide' => esc_html__('Hide', 'nanaobiriyeboah'), 
            ), 
            'default' => 'show'
        ),
        array(
            'title'    => esc_html__('404 Banner Titile', 'nanaobiriyeboah'),
            'type' => 'text',
            'id'       => 'nanaobiriyeboah_404_banner_title',
            'placeholder' => esc_html__( '404 Banner Titile', 'nanaobiriyeboah'),
            'required'    => array('nanaobiriyeboah_404_title', '=', 'show')
        ),
        array(
            'id'       => 'nanaobiriyeboah_404_banner_breadcrumb',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Breadcrumb', 'nanaobiriyeboah'),
            'options' => array(
                'show' => esc_html__('Show', 'nanaobiriyeboah'), 
                'hide' => esc_html__('Hide', 'nanaobiriyeboah'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'nanaobiriyeboah_404_banner_upload',
            'type'     => 'media', 
            'url'      => true,
            'title'    => __('Upload Banner', 'nanaobiriyeboah'),
            'default'  => array(
                'url'=> nanaobiriyeboah_IMAGES.'/blog/banner/blog_details_img.jpg',
            ),
            'url'      => false

        ),
        array(
            'id'        => 'nanaobiriyeboahs_404_banner_overly',
            'type'      => 'color_rgba',
            'title'     => 'Banner Overly Color',
            'mode'      => 'background',
            'output'    => array( '.blog_breadcrumbs_area_two.banner-404 .overlay_bg' ),
            'default'   => array(
                'color'     => '#000',
                'alpha'     => .5
            ),                        
        ),
      )
));