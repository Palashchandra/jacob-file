<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    $opt_name = 'nanaobiriyeboah';

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'display_name'         => $theme->get( 'Name' ),
        'display_version'      => $theme->get( 'Version' ),
        'menu_title'           => esc_html__( 'nanaobiriyeboah Options', 'nanaobiriyeboah' ),
        'customizer'           => true,
		'dev_mode'             => 'true'
    );

    Redux::setArgs( $opt_name, $args );

	require nanaobiriyeboah_THEMEROOT_DIR . '/lib/options/opt_header.php';
	require nanaobiriyeboah_THEMEROOT_DIR . '/lib/options/opt_sub_header.php';
	require nanaobiriyeboah_THEMEROOT_DIR . '/lib/options/opt_banner.php';
	require nanaobiriyeboah_THEMEROOT_DIR . '/lib/options/opt_banner_search.php';
	require nanaobiriyeboah_THEMEROOT_DIR . '/lib/options/opt_banner_404.php';
    require nanaobiriyeboah_THEMEROOT_DIR . '/lib/options/opt_popup.php';
	require nanaobiriyeboah_THEMEROOT_DIR . '/lib/options/opt_style.php';
