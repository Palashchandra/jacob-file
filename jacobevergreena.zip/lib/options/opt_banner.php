<?php

Redux::set_section('nanaobiriyeboah', array(
    'title'            => esc_html__( 'Banner Setting', 'nanaobiriyeboah' ),
    'id'               => 'headers_typo_opt',
    'icon'             => 'el el-picture',
));

// Page Banner 
Redux::set_section('nanaobiriyeboah', array(
    'title'            => esc_html__( 'Page Banner', 'nanaobiriyeboah' ),
    'id'               => 'Banner',
    'icon'             => 'el el-cog',
    'subsection' => true,
    'fields'           => array(
        array(
            'id'       => 'nanaobiriyeboah_page_banner_toggle',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Page Banner', 'nanaobiriyeboah'),
            'subtitle' => esc_html__('Show Hide Page Banner Globally ', 'nanaobiriyeboah'),
            'options' => array(
                'show' => esc_html__('Show Banner', 'nanaobiriyeboah'), 
                'hide' => esc_html__('Hide Banner', 'nanaobiriyeboah'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'nanaobiriyeboah_page_banner_breadcrumb',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Page Breadcrumb', 'nanaobiriyeboah'),
            'options' => array(
                'show' => esc_html__('Show', 'nanaobiriyeboah'), 
                'hide' => esc_html__('Hide', 'nanaobiriyeboah'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'nanaobiriyeboah_page_banner_title',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Page Title', 'nanaobiriyeboah'),
            'options' => array(
                'show' => esc_html__('Show', 'nanaobiriyeboah'), 
                'hide' => esc_html__('Hide', 'nanaobiriyeboah'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'nanaobiriyeboah_page_banner_upload',
            'type'     => 'media', 
            'url'      => true,
            'title'    => __('Upload Banner', 'nanaobiriyeboah'),
            'default'  => array(
                'url'=> nanaobiriyeboah_IMAGES.'/blog/banner/blog_details_img.jpg',
            ),
            'url'      => false

        ),
        array(
            'id'        => 'nanaobiriyeboah_page_banner_overly',
            'type'      => 'color_rgba',
            'title'     => 'Banner Overly Color',
            'mode'      => 'background',
            'output'    => array( '.blog_breadcrumbs_area_two.page-banner .overlay_bg' ),
            'default'   => array(
                'color'     => '#000',
                'alpha'     => .5
            ),                        
        ),
      )
));


// Blog Banner 

Redux::set_section('nanaobiriyeboah', array(
    'title'            => esc_html__( 'Blog Banner', 'nanaobiriyeboah' ),
    'id'               => 'blog_banner',
    'icon'             => 'el el-cog',
    'subsection' => true,
    'fields'           => array(
        array(
            'id'       => 'nanaobiriyeboah_blog_banner_title',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Blog Title', 'nanaobiriyeboah'),
            'options' => array(
                'show' => esc_html__('Show', 'nanaobiriyeboah'), 
                'hide' => esc_html__('Hide', 'nanaobiriyeboah'), 
            ), 
            'default' => 'show'
        ),
        array( 
            'title'    => esc_html__('Blog title', 'nanaobiriyeboah'),
            'id' => 'nanaobiriyeboah_blog_title',
            'type' => 'text',
            'required' => array('nanaobiriyeboah_blog_banner_title', '=' , 'show')
        ),
        array( 
            'title'    => esc_html__('Blog Description', 'nanaobiriyeboah'),
            'id' => 'nanaobiriyeboah_blog_description',
            'type' => 'textarea',
        ),
      )
));



