<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package nanaobiriyeboah
 */

get_header();

?>

	<main id="primary" class="site-main">

	<?php get_template_part('template-parts/banner/banner', 'blog'); ?>

	<div class="feature_post_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="feature_post">
						<?php
							//only feature post
							$args = array(
								'post_type' => 'post',
								'meta_key' => 'feature_post',
								'meta_value' => true,
							);

							$feature_post = new WP_Query($args);

							if($feature_post->have_posts()) :
								while($feature_post->have_posts()) : $feature_post->the_post();
									?>
										<div class="feature_post_content">
											<div class="post_meta">
												<div class="category_list">
													<?php 
														$categories = get_the_category();
														if ($categories) {
															// Get the first category from the array
															$first_category = $categories[0];
															
															// Output the first category name with the static "5 min read" span tag
															echo '<p>' . esc_html($first_category->name) . ' <span>5 min read</span></p>';
														}
													?>
												</div>
												<p class="post_date"><?php echo get_the_date(); ?></p>
											</div>
											
											<h3 class="title"><?php echo get_the_title(); ?></h3>
											<a href="<?php echo get_the_permalink( ); ?>" class="cu_btn base_btn">Learn More <i class="fas fa-arrow-right"></i></a>
										</div>
										<div class="feature_post_img">
											<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#" class="img-fluid">
										</div>
									<?php
								endwhile;
								wp_reset_postdata();
							else :
								// No featured posts found
								echo '<p>No featured posts found.</p>';
							endif;
						?>
					</div>
				</div>
			</div>
			<div class="filter_inner">
				<div class="filter_btn">
					<?php echo esc_html__('Filters', 'nanaobiriyeboah') ?>
					<svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
					<g clip-path="url(#clip0_4090_11843)">
					<path d="M0.75 5.21334H12.169C12.5131 6.77986 13.9121 7.9559 15.5805 7.9559C17.2488 7.9559 18.6478 6.7799 18.9919 5.21334H23.25C23.6642 5.21334 24 4.87753 24 4.46334C24 4.04915 23.6642 3.71334 23.25 3.71334H18.9915C18.6467 2.14762 17.2459 0.970825 15.5805 0.970825C13.9141 0.970825 12.5139 2.14743 12.1693 3.71334H0.75C0.335812 3.71334 0 4.04915 0 4.46334C0 4.87753 0.335812 5.21334 0.75 5.21334ZM13.588 4.46531C13.588 4.46264 13.588 4.45992 13.588 4.45725C13.5913 3.36192 14.4851 2.47087 15.5805 2.47087C16.6743 2.47087 17.5681 3.3607 17.5728 4.45551L17.573 4.46653C17.5712 5.56373 16.6781 6.45595 15.5805 6.45595C14.4833 6.45595 13.5904 5.56462 13.5879 4.46808L13.588 4.46531ZM23.25 20.7515H18.9915C18.6467 19.1858 17.2459 18.009 15.5805 18.009C13.9141 18.009 12.5139 19.1857 12.1693 20.7515H0.75C0.335812 20.7515 0 21.0873 0 21.5015C0 21.9157 0.335812 22.2515 0.75 22.2515H12.169C12.5131 23.818 13.9121 24.9941 15.5805 24.9941C17.2488 24.9941 18.6478 23.818 18.9919 22.2515H23.25C23.6642 22.2515 24 21.9157 24 21.5015C24 21.0873 23.6642 20.7515 23.25 20.7515ZM15.5805 23.4941C14.4833 23.4941 13.5904 22.6027 13.5879 21.5062L13.588 21.5035C13.588 21.5008 13.588 21.4981 13.588 21.4954C13.5913 20.4001 14.4851 19.509 15.5805 19.509C16.6743 19.509 17.5681 20.3988 17.5728 21.4936L17.573 21.5046C17.5714 22.6019 16.6782 23.4941 15.5805 23.4941ZM23.25 12.2325H11.831C11.4869 10.6659 10.0879 9.48993 8.41955 9.48993C6.75117 9.48993 5.35223 10.6659 5.00808 12.2325H0.75C0.335812 12.2325 0 12.5683 0 12.9824C0 13.3967 0.335812 13.7324 0.75 13.7324H5.00845C5.35331 15.2981 6.75413 16.475 8.41955 16.475C10.0859 16.475 11.4861 15.2983 11.8307 13.7324H23.25C23.6642 13.7324 24 13.3967 24 12.9824C24 12.5683 23.6642 12.2325 23.25 12.2325ZM10.412 12.9805C10.412 12.9832 10.412 12.9859 10.412 12.9885C10.4087 14.0839 9.51492 14.9749 8.41955 14.9749C7.32572 14.9749 6.43191 14.0851 6.42717 12.9903L6.42703 12.9794C6.42867 11.882 7.32188 10.9899 8.41955 10.9899C9.5167 10.9899 10.4096 11.8812 10.4121 12.9778L10.412 12.9805Z" fill="black"/>
					</g>
					<defs>
					<clipPath id="clip0_4090_11843">
					<rect width="24" height="24" fill="white" transform="translate(0 0.982422)"/>
					</clipPath>
					</defs>
					</svg>
				</div>
				<div class="blog_sidebar">
					<?php
					function generate_taxonomy_checkboxes_f($taxonomy) {
						$args = array(
							'taxonomy'   => $taxonomy,
							'hide_empty' => true,
						);

						$categories = get_categories($args);

						foreach ($categories as $category) {
							$category_id = $category->term_id;
							$category_posts = get_posts(array(
								'post_type' => 'post',
								'tax_query' => array(
									array(
										'taxonomy' => $taxonomy,
										'field'    => 'term_id',
										'terms'    => $category_id,
									),
								),
							));

							if (!empty($category_posts)) {
								echo '<div class="check_item"><label>';
								echo '<input type="checkbox" name="' . esc_attr($taxonomy) . '[]" value="' . esc_attr($category_id) . '">';
								echo $category->name;
								echo '</label></div>';
							}
						}
					}
					?>

					<div class="sidebar_item sidebar_dropdown">
						<div class="dropdown_title"> <h4>Categories</h4> <i class="fas fa-sort-down"></i></div>
						<div class="dropdown_content" id="post-category-list">
							<?php generate_taxonomy_checkboxes_f('category'); ?>
						</div>
					</div>

					<div class="sidebar_item sidebar_dropdown">
						<div class="dropdown_title"> <h4>Topic</h4> <i class="fas fa-sort-down"></i></div>
						<div class="dropdown_content" id="post-topic-list">
							<?php generate_taxonomy_checkboxes_f('topic'); ?>
						</div>
					</div>

					<div class="sidebar_item sidebar_dropdown">
						<div class="dropdown_title"> <h4>Provider</h4> <i class="fas fa-sort-down"></i></div>
						<div class="dropdown_content" id="post-provider-list">
							<?php generate_taxonomy_checkboxes_f('provider'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="blog_section">
		<div class="container">
			<div class="row align-items-center justify-content-center">
				<div class="col-lg-8">
					<div class="section_title text-center">
						<h2 class="title">Popular Categories</h2>
						<div class="popular_category">
							<?php
								$categories = get_categories(array(
									'orderby' => 'count',
									'order' => 'DESC',
									'number' => 5,        // Limit to 5 categories
                                    'hide_empty' => false // Include categories with no posts
								));
								if ($categories) {
									// Output top 5 categories in an unordered list with links
									echo '<ul class="list-unstyled">';
									foreach ($categories as $category) {
										echo '<li class="item"><a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a></li>';
									}
									echo '</ul>';
								}
							?>
							<div class="swiper-button-prev"></div>
  							<div class="swiper-button-next"></div>
						</div>
						
					</div>
				</div>
			</div>
		    <div class="row">
				<div class="col-lg-3 col-md-4">
					<?php
						function generate_blog_taxonomy_checkboxes() {
							// Get all taxonomies associated with the 'post' post type
							$post_taxonomies = get_object_taxonomies('post', 'objects');

							// Array to store taxonomy names specifically associated with blog posts
							$blog_taxonomy_names = array('category', 'post_tag'); // Default taxonomies

							// Loop through each taxonomy associated with the 'post' post type
							foreach ($post_taxonomies as $taxonomy_name => $taxonomy) {
								// Check if the taxonomy is public and not already in the array
								if ($taxonomy->public && !in_array($taxonomy_name, $blog_taxonomy_names)) {
									$blog_taxonomy_names[] = $taxonomy_name; // Add taxonomy name to the array
								}
							}

							// Loop through each taxonomy in the blog_taxonomy_names array
							foreach ($blog_taxonomy_names as $taxonomy_name) {
								$taxonomy = get_taxonomy($taxonomy_name); // Retrieve taxonomy object

								if ($taxonomy && $taxonomy->public) { // Check if taxonomy is public and exists
									$args = array(
										'taxonomy'   => $taxonomy_name,
										'hide_empty' => true,
									);

									$terms = get_terms($args);

									if (!empty($terms)) {
										echo '<div class="sidebar_item sidebar_dropdown">';
										echo '<div class="dropdown_title"> <h4>' . esc_html($taxonomy->labels->singular_name) . '</h4> <i class="fas fa-sort-down"></i></div>';
										echo '<div class="dropdown_content">';
										
										foreach ($terms as $term) {
											$term_id = $term->term_id;
											$term_posts = get_posts(array(
												'post_type' => 'post',
												'tax_query' => array(
													array(
														'taxonomy' => $taxonomy_name,
														'field'    => 'term_id',
														'terms'    => $term_id,
													),
												),
											));

											if (!empty($term_posts)) {
												echo '<div class="check_item"><label>';
												echo '<input type="checkbox" name="' . esc_attr($taxonomy_name) . '[]" value="' . esc_attr($term_id) . '">';
												echo esc_html($term->name) . ' (' . count($term_posts) . ')';
												echo '</label></div>';
											}
										}

										echo '</div></div>'; // Close dropdown_content and sidebar_item
									}
								}
							}
						}
					?>
					<div class="blog_sidebar">
						<?php generate_blog_taxonomy_checkboxes(); ?>
					</div>
				</div>
				<div class="col-lg-9 col-md-8">
					<div class="ja_blog_post_wrapper">
						<!-- post list -->
						<div id="post-list" class="post-list-wrapper"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>
		jQuery(document).ready(function ($) {
			const loadpostData = (pageNumber) => {

				const categoryIds = $('input[name="category[]"]:checked').map(function () {
					return $(this).val();
				}).get();
				
				const topicIds = $('input[name="topic[]"]:checked').map(function () {
					return $(this).val();
				}).get();

				const providerIds = $('input[name="provider[]"]:checked').map(function () {
					return $(this).val();
				}).get();

				const tagIds = $('input[name="post_tag[]"]:checked').map(function () {
					return $(this).val();
				}).get();

				const data = {
					action: 's_post_widget_ajax',
					category: categoryIds,
					topic: topicIds,
					provider: providerIds,
					post_tag: tagIds,
					paged: pageNumber,
				};

				$.ajax({
					url: '<?php echo admin_url("admin-ajax.php") ?>',
					type: 'POST',
					data: data,					
					success: (response) => {
						$('#post-list').html(response); 
					},
				});
			};

			$(document).on('click', '.pagination a', function (e) {
				e.preventDefault();
				const pageNumber = $(this).attr('href').split('/').pop(); // Get page number from pagination link
				loadpostData(pageNumber);
			});

			// Initial load with all posts
			loadpostData( 1, '' );

			$('.sidebar_dropdown input').on('change', function() {
				loadpostData(1, '');
			});
			
			function filter_dropdown() {
				if ($(window).width()) {
					$(".filter_inner .filter_btn").on("click", function (event) {
					$(this).parent().find(".blog_sidebar").first().toggle(700);
					});
				}
			}
			filter_dropdown();


			// Check device size and add swiper-wrapper class using jQuery
			function addSwiperWrapperClass() {
				var screenWidth = $(window).width();
				var popularCategory = $('.popular_category ul');
				var slide = $('.popular_category ul li');
				if (screenWidth <= 767 && !popularCategory.hasClass('swiper-wrapper')) {
				  popularCategory.addClass('swiper-wrapper');
				  slide.addClass('swiper-slide');
				} else if (screenWidth > 767 && popularCategory.hasClass('swiper-wrapper')) {
				  popularCategory.removeClass('swiper-wrapper');
				  slide.removeClass('swiper-slide');
				}
			}

			// Call the function initially and on window resize
			addSwiperWrapperClass();
			$(window).resize(addSwiperWrapperClass);
			
			var swiper = new Swiper('.popular_category', {
				// Optional parameters
				slidesPerView: 1,
				spaceBetween: 30,
				loop: true,
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				 },
			});
		});
	</script>
		 
	</main><!-- #main -->

<?php

get_footer();
